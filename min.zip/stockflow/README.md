# StockFlow MVP

A minimal multi-tenant SaaS Inventory Management System built with **Spring Boot 3** + **React 18**.

## Tech Stack

| Layer | Tech |
|-------|------|
| Backend | Java 21, Spring Boot 3.2, Spring Security, Spring Data JPA |
| Database | H2 (file-based, swap to PostgreSQL/MySQL for production) |
| Auth | JWT (JJWT 0.12) + BCrypt |
| Frontend | React 18, TypeScript, React Router 6 |

## Project Structure

```
stockflow/
├── pom.xml                          # Maven build
├── src/
│   ├── main/java/com/stockflow/
│   │   ├── StockFlowApplication.java
│   │   ├── config/SecurityConfig.java
│   │   ├── controller/              # AuthController, ProductController, DashboardController, SettingsController
│   │   ├── dto/                     # Request/Response DTOs
│   │   ├── entity/                  # Organization, User, Product
│   │   ├── exception/GlobalExceptionHandler.java
│   │   ├── repository/              # JPA Repositories
│   │   ├── security/                # JwtUtils, JwtAuthFilter, UserDetailsServiceImpl
│   │   └── service/                 # AuthService, ProductService, DashboardService, SettingsService
│   └── main/resources/
│       └── application.properties
└── frontend/
    ├── package.json
    ├── public/index.html
    └── src/
        ├── App.tsx, api.ts, AuthContext.tsx, types.ts
        ├── components/Layout.tsx
        └── pages/                   # LoginPage, SignupPage, DashboardPage, ProductsPage, ProductFormPage, SettingsPage
```

## Running Locally

### Backend

**Prerequisites**: Java 21+, Maven 3.9+

```bash
cd stockflow
mvn spring-boot:run
# API available at http://localhost:8080
# H2 Console at http://localhost:8080/h2-console
```

### Frontend

**Prerequisites**: Node 18+

```bash
cd stockflow/frontend
npm install
npm start
# UI available at http://localhost:3000
```

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/signup` | Register + create org |
| POST | `/api/auth/login` | Login, returns JWT |

**Signup body:**
```json
{
  "email": "admin@mystore.com",
  "password": "password123",
  "organizationName": "My Test Store"
}
```

### Products (requires `Authorization: Bearer <token>`)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/products` | List products (optional `?query=`) |
| GET | `/api/products/{id}` | Get single product |
| POST | `/api/products` | Create product |
| PUT | `/api/products/{id}` | Update product |
| DELETE | `/api/products/{id}` | Soft delete |
| PATCH | `/api/products/{id}/adjust-stock` | Adjust quantity by ±N |

**Create/Update body:**
```json
{
  "name": "Widget A",
  "sku": "WGT-001",
  "description": "A great widget",
  "quantityOnHand": 100,
  "costPrice": 5.00,
  "sellingPrice": 12.99,
  "lowStockThreshold": 10
}
```

### Dashboard
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/dashboard` | Summary + low stock items |

### Settings
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/settings` | Get org settings |
| PUT | `/api/settings` | Update default low stock threshold |

## Production Database Switch

To use PostgreSQL, update `application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/stockflow
spring.datasource.username=your_user
spring.datasource.password=your_password
spring.datasource.driver-class-name=org.postgresql.Driver
```
And add to `pom.xml`:
```xml
<dependency>
  <groupId>org.postgresql</groupId>
  <artifactId>postgresql</artifactId>
  <scope>runtime</scope>
</dependency>
```

## Security Notes

- Passwords hashed with BCrypt (strength 10)
- JWT tokens expire after 24 hours
- All product/dashboard/settings APIs require valid JWT
- Data is scoped per organization — no cross-tenant leaks
- H2 console restricted to same-origin only
