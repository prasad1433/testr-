package com.stockflow.service;

import com.stockflow.dto.SettingsRequest;
import com.stockflow.entity.Organization;
import com.stockflow.repository.OrganizationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class SettingsService {

    private final OrganizationRepository organizationRepository;
    private final UserContextService userContextService;

    @Transactional(readOnly = true)
    public Map<String, Object> getSettings() {
        Long orgId = userContextService.currentOrgId();
        Organization org = organizationRepository.findById(orgId).orElseThrow();
        return Map.of(
                "defaultLowStockThreshold", org.getDefaultLowStockThreshold() != null ? org.getDefaultLowStockThreshold() : 5,
                "organizationName", org.getName()
        );
    }

    @Transactional
    public Map<String, Object> updateSettings(SettingsRequest request) {
        Long orgId = userContextService.currentOrgId();
        Organization org = organizationRepository.findById(orgId).orElseThrow();
        if (request.getDefaultLowStockThreshold() != null) {
            org.setDefaultLowStockThreshold(request.getDefaultLowStockThreshold());
        }
        organizationRepository.save(org);
        return Map.of(
                "defaultLowStockThreshold", org.getDefaultLowStockThreshold(),
                "organizationName", org.getName()
        );
    }
}
