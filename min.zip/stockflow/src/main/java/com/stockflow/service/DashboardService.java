package com.stockflow.service;

import com.stockflow.dto.DashboardResponse;
import com.stockflow.dto.ProductResponse;
import com.stockflow.entity.Organization;
import com.stockflow.entity.Product;
import com.stockflow.repository.OrganizationRepository;
import com.stockflow.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final ProductRepository productRepository;
    private final OrganizationRepository organizationRepository;
    private final UserContextService userContextService;
    private final ProductService productService;

    @Transactional(readOnly = true)
    public DashboardResponse getDashboard() {
        Long orgId = userContextService.currentOrgId();
        Organization org = organizationRepository.findById(orgId).orElseThrow();
        int globalThreshold = org.getDefaultLowStockThreshold() != null ? org.getDefaultLowStockThreshold() : 5;

        long totalProducts = productRepository.countByOrganizationId(orgId);
        long totalQty = productRepository.sumQuantityByOrganizationId(orgId);

        List<Product> allProducts = productRepository.findByOrganizationIdAndDeletedFalse(orgId);
        List<ProductResponse> lowStockItems = allProducts.stream()
                .filter(p -> {
                    int threshold = p.getLowStockThreshold() != null ? p.getLowStockThreshold() : globalThreshold;
                    return p.getQuantityOnHand() <= threshold;
                })
                .map(p -> productService.toResponse(p, globalThreshold))
                .collect(Collectors.toList());

        DashboardResponse response = new DashboardResponse();
        response.setTotalProducts(totalProducts);
        response.setTotalQuantityOnHand(totalQty);
        response.setLowStockItems(lowStockItems);
        return response;
    }
}
