package com.stockflow.service;

import com.stockflow.dto.ProductRequest;
import com.stockflow.dto.ProductResponse;
import com.stockflow.dto.StockAdjustRequest;
import com.stockflow.entity.Organization;
import com.stockflow.entity.Product;
import com.stockflow.repository.OrganizationRepository;
import com.stockflow.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final OrganizationRepository organizationRepository;
    private final UserContextService userContextService;

    @Transactional(readOnly = true)
    public List<ProductResponse> findAll(String query) {
        Long orgId = userContextService.currentOrgId();
        List<Product> products = (query != null && !query.isBlank())
                ? productRepository.searchByNameOrSku(orgId, query)
                : productRepository.findByOrganizationIdAndDeletedFalse(orgId);
        Organization org = organizationRepository.findById(orgId).orElseThrow();
        return products.stream().map(p -> toResponse(p, org.getDefaultLowStockThreshold())).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ProductResponse findById(Long id) {
        Long orgId = userContextService.currentOrgId();
        Product product = productRepository.findByIdAndOrganizationIdAndDeletedFalse(id, orgId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));
        Organization org = organizationRepository.findById(orgId).orElseThrow();
        return toResponse(product, org.getDefaultLowStockThreshold());
    }

    @Transactional
    public ProductResponse create(ProductRequest request) {
        Long orgId = userContextService.currentOrgId();
        if (productRepository.existsBySkuAndOrganizationIdAndDeletedFalse(request.getSku(), orgId)) {
            throw new IllegalArgumentException("SKU already exists in your organization");
        }
        Organization org = organizationRepository.findById(orgId).orElseThrow();
        String email = userContextService.currentUser().getEmail();

        Product product = new Product();
        mapRequestToProduct(request, product);
        product.setOrganization(org);
        product.setLastUpdatedBy(email);
        product = productRepository.save(product);
        return toResponse(product, org.getDefaultLowStockThreshold());
    }

    @Transactional
    public ProductResponse update(Long id, ProductRequest request) {
        Long orgId = userContextService.currentOrgId();
        Product product = productRepository.findByIdAndOrganizationIdAndDeletedFalse(id, orgId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        // If SKU changed, check uniqueness
        if (!product.getSku().equals(request.getSku()) &&
                productRepository.existsBySkuAndOrganizationIdAndDeletedFalse(request.getSku(), orgId)) {
            throw new IllegalArgumentException("SKU already exists in your organization");
        }

        mapRequestToProduct(request, product);
        product.setLastUpdatedBy(userContextService.currentUser().getEmail());
        product = productRepository.save(product);

        Organization org = organizationRepository.findById(orgId).orElseThrow();
        return toResponse(product, org.getDefaultLowStockThreshold());
    }

    @Transactional
    public void delete(Long id) {
        Long orgId = userContextService.currentOrgId();
        Product product = productRepository.findByIdAndOrganizationIdAndDeletedFalse(id, orgId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));
        product.setDeleted(true);
        productRepository.save(product);
    }

    @Transactional
    public ProductResponse adjustStock(Long id, StockAdjustRequest request) {
        Long orgId = userContextService.currentOrgId();
        Product product = productRepository.findByIdAndOrganizationIdAndDeletedFalse(id, orgId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        int newQty = product.getQuantityOnHand() + request.getAdjustment();
        if (newQty < 0) {
            throw new IllegalArgumentException("Quantity cannot go below 0");
        }
        product.setQuantityOnHand(newQty);
        product.setLastUpdatedBy(userContextService.currentUser().getEmail());
        product = productRepository.save(product);

        Organization org = organizationRepository.findById(orgId).orElseThrow();
        return toResponse(product, org.getDefaultLowStockThreshold());
    }

    private void mapRequestToProduct(ProductRequest request, Product product) {
        product.setName(request.getName());
        product.setSku(request.getSku());
        product.setDescription(request.getDescription());
        product.setQuantityOnHand(request.getQuantityOnHand());
        product.setCostPrice(request.getCostPrice());
        product.setSellingPrice(request.getSellingPrice());
        product.setLowStockThreshold(request.getLowStockThreshold());
    }

    public ProductResponse toResponse(Product product, int globalThreshold) {
        ProductResponse res = new ProductResponse();
        res.setId(product.getId());
        res.setName(product.getName());
        res.setSku(product.getSku());
        res.setDescription(product.getDescription());
        res.setQuantityOnHand(product.getQuantityOnHand());
        res.setCostPrice(product.getCostPrice());
        res.setSellingPrice(product.getSellingPrice());
        res.setLowStockThreshold(product.getLowStockThreshold());
        res.setLastUpdatedBy(product.getLastUpdatedBy());
        res.setCreatedAt(product.getCreatedAt());
        res.setUpdatedAt(product.getUpdatedAt());

        int threshold = product.getLowStockThreshold() != null ? product.getLowStockThreshold() : globalThreshold;
        res.setLowStock(product.getQuantityOnHand() <= threshold);
        return res;
    }
}
