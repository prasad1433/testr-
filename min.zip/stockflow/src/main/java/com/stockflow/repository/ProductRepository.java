package com.stockflow.repository;

import com.stockflow.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findByOrganizationIdAndDeletedFalse(Long organizationId);

    Optional<Product> findByIdAndOrganizationIdAndDeletedFalse(Long id, Long organizationId);

    boolean existsBySkuAndOrganizationIdAndDeletedFalse(String sku, Long organizationId);

    @Query("SELECT p FROM Product p WHERE p.organization.id = :orgId AND p.deleted = false " +
           "AND (LOWER(p.name) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(p.sku) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<Product> searchByNameOrSku(@Param("orgId") Long orgId, @Param("query") String query);

    @Query("SELECT COUNT(p) FROM Product p WHERE p.organization.id = :orgId AND p.deleted = false")
    long countByOrganizationId(@Param("orgId") Long orgId);

    @Query("SELECT COALESCE(SUM(p.quantityOnHand), 0) FROM Product p WHERE p.organization.id = :orgId AND p.deleted = false")
    long sumQuantityByOrganizationId(@Param("orgId") Long orgId);
}
