package com.stockflow.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class StockAdjustRequest {

    @NotNull
    private Integer adjustment;

    private String note;
}
