package com.stockflow.dto;

import lombok.Data;
import java.util.List;

@Data
public class DashboardResponse {
    private long totalProducts;
    private long totalQuantityOnHand;
    private List<ProductResponse> lowStockItems;
}
