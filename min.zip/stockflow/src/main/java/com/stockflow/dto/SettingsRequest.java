package com.stockflow.dto;

import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class SettingsRequest {
    @Min(0)
    private Integer defaultLowStockThreshold;
}
