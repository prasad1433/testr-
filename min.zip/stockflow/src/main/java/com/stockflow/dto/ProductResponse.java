package com.stockflow.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ProductResponse {
    private Long id;
    private String name;
    private String sku;
    private String description;
    private Integer quantityOnHand;
    private BigDecimal costPrice;
    private BigDecimal sellingPrice;
    private Integer lowStockThreshold;
    private boolean lowStock;
    private String lastUpdatedBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
