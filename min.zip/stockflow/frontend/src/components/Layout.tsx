import React from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const styles: Record<string, React.CSSProperties> = {
  shell: { display: 'flex', minHeight: '100vh' },
  sidebar: {
    width: 220, background: '#1e293b', color: '#e2e8f0',
    display: 'flex', flexDirection: 'column', padding: '24px 0',
  },
  brand: { fontSize: 22, fontWeight: 700, color: '#38bdf8', padding: '0 24px 24px' },
  nav: { flex: 1, display: 'flex', flexDirection: 'column', gap: 4, padding: '0 12px' },
  footer: { padding: '16px 24px', fontSize: 13, color: '#94a3b8' },
  main: { flex: 1, padding: 32, overflowY: 'auto' },
  logoutBtn: {
    background: 'none', border: 'none', color: '#f87171', cursor: 'pointer',
    fontSize: 14, padding: '8px 12px', textAlign: 'left', borderRadius: 6,
  },
};

const navLinkStyle = ({ isActive }: { isActive: boolean }): React.CSSProperties => ({
  display: 'block', padding: '8px 12px', borderRadius: 6, textDecoration: 'none',
  color: isActive ? '#38bdf8' : '#cbd5e1',
  background: isActive ? 'rgba(56,189,248,0.1)' : 'transparent',
  fontWeight: isActive ? 600 : 400,
});

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/login'); };

  return (
    <div style={styles.shell}>
      <aside style={styles.sidebar}>
        <div style={styles.brand}>📦 StockFlow</div>
        <nav style={styles.nav}>
          <NavLink to="/dashboard" style={navLinkStyle}>Dashboard</NavLink>
          <NavLink to="/products" style={navLinkStyle}>Products</NavLink>
          <NavLink to="/settings" style={navLinkStyle}>Settings</NavLink>
        </nav>
        <div style={styles.footer}>
          <div style={{ marginBottom: 4 }}>{user?.email}</div>
          <div style={{ fontSize: 11, color: '#64748b', marginBottom: 12 }}>{user?.organizationName}</div>
          <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
        </div>
      </aside>
      <main style={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}
