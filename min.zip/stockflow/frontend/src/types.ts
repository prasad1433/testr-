export interface AuthResponse {
  token: string;
  email: string;
  organizationName: string;
  organizationId: number;
}

export interface Product {
  id: number;
  name: string;
  sku: string;
  description?: string;
  quantityOnHand: number;
  costPrice?: number;
  sellingPrice?: number;
  lowStockThreshold?: number;
  lowStock: boolean;
  lastUpdatedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ProductForm {
  name: string;
  sku: string;
  description: string;
  quantityOnHand: number;
  costPrice: string;
  sellingPrice: string;
  lowStockThreshold: string;
}

export interface Dashboard {
  totalProducts: number;
  totalQuantityOnHand: number;
  lowStockItems: Product[];
}
