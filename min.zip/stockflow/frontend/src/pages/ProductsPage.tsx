import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import { Product } from '../types';

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [adjustId, setAdjustId] = useState<number | null>(null);
  const [adjustValue, setAdjustValue] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const fetchProducts = (q = '') => {
    setLoading(true);
    api.get('/products', { params: q ? { query: q } : {} })
      .then(r => setProducts(r.data))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchProducts(); }, []);

  const handleSearch = (e: React.FormEvent) => { e.preventDefault(); fetchProducts(query); };

  const handleDelete = async (id: number) => {
    await api.delete(`/products/${id}`);
    setDeleteConfirm(null);
    fetchProducts(query);
  };

  const handleAdjust = async (id: number) => {
    const adj = parseInt(adjustValue);
    if (isNaN(adj)) return;
    await api.patch(`/products/${id}/adjust-stock`, { adjustment: adj });
    setAdjustId(null);
    setAdjustValue('');
    fetchProducts(query);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700 }}>Products</h2>
        <Link to="/products/new" style={addBtn}>+ Add Product</Link>
      </div>

      <form onSubmit={handleSearch} style={{ marginBottom: 16, display: 'flex', gap: 8 }}>
        <input
          style={{ ...searchInput, flex: 1 }}
          placeholder="Search by name or SKU..."
          value={query}
          onChange={e => setQuery(e.target.value)}
        />
        <button style={searchBtn} type="submit">Search</button>
        {query && <button style={{ ...searchBtn, background: '#64748b' }} type="button" onClick={() => { setQuery(''); fetchProducts(); }}>Clear</button>}
      </form>

      {loading ? (
        <div style={{ color: '#64748b', padding: 20 }}>Loading...</div>
      ) : products.length === 0 ? (
        <div style={{ color: '#64748b', textAlign: 'center', padding: 48, background: '#f8fafc', borderRadius: 8 }}>
          No products found. <Link to="/products/new" style={{ color: '#0ea5e9' }}>Add your first product</Link>
        </div>
      ) : (
        <div style={{ background: '#fff', borderRadius: 8, boxShadow: '0 1px 4px rgba(0,0,0,0.04)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                <th style={th}>Name</th>
                <th style={th}>SKU</th>
                <th style={th}>Qty</th>
                <th style={th}>Status</th>
                <th style={th}>Selling Price</th>
                <th style={th}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id} style={{ borderTop: '1px solid #f1f5f9' }}>
                  <td style={td}><strong>{p.name}</strong></td>
                  <td style={td}><code style={{ fontSize: 12, background: '#f1f5f9', padding: '2px 6px', borderRadius: 4 }}>{p.sku}</code></td>
                  <td style={td}>
                    {adjustId === p.id ? (
                      <span style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
                        <input
                          style={{ width: 60, padding: '4px 8px', border: '1px solid #d1d5db', borderRadius: 6, fontSize: 13 }}
                          placeholder="±n"
                          value={adjustValue}
                          onChange={e => setAdjustValue(e.target.value)}
                          autoFocus
                        />
                        <button style={smallBtn} onClick={() => handleAdjust(p.id)}>✓</button>
                        <button style={{ ...smallBtn, background: '#64748b' }} onClick={() => setAdjustId(null)}>✕</button>
                      </span>
                    ) : (
                      <span
                        style={{ cursor: 'pointer', fontWeight: 600, color: p.quantityOnHand === 0 ? '#dc2626' : '#1e293b' }}
                        title="Click to adjust stock"
                        onClick={() => setAdjustId(p.id)}
                      >
                        {p.quantityOnHand}
                      </span>
                    )}
                  </td>
                  <td style={td}>
                    {p.lowStock
                      ? <span style={badgeLow}>Low Stock</span>
                      : <span style={badgeOk}>In Stock</span>}
                  </td>
                  <td style={td}>{p.sellingPrice != null ? `$${Number(p.sellingPrice).toFixed(2)}` : '—'}</td>
                  <td style={td}>
                    <Link to={`/products/${p.id}/edit`} style={{ color: '#0ea5e9', marginRight: 12, fontSize: 13, textDecoration: 'none' }}>Edit</Link>
                    {deleteConfirm === p.id ? (
                      <span style={{ fontSize: 13 }}>
                        Sure?{' '}
                        <span style={{ color: '#dc2626', cursor: 'pointer', marginRight: 8 }} onClick={() => handleDelete(p.id)}>Yes</span>
                        <span style={{ color: '#64748b', cursor: 'pointer' }} onClick={() => setDeleteConfirm(null)}>No</span>
                      </span>
                    ) : (
                      <span style={{ color: '#dc2626', cursor: 'pointer', fontSize: 13 }} onClick={() => setDeleteConfirm(p.id)}>Delete</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const th: React.CSSProperties = { padding: '12px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px' };
const td: React.CSSProperties = { padding: '12px 16px', fontSize: 14 };
const addBtn: React.CSSProperties = { background: '#0ea5e9', color: '#fff', padding: '10px 18px', borderRadius: 8, textDecoration: 'none', fontWeight: 600, fontSize: 14 };
const searchInput: React.CSSProperties = { padding: '10px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14 };
const searchBtn: React.CSSProperties = { padding: '10px 16px', background: '#0ea5e9', color: '#fff', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 600, fontSize: 14 };
const badgeLow: React.CSSProperties = { background: '#fef2f2', color: '#dc2626', padding: '2px 8px', borderRadius: 12, fontSize: 12, fontWeight: 600 };
const badgeOk: React.CSSProperties = { background: '#f0fdf4', color: '#16a34a', padding: '2px 8px', borderRadius: 12, fontSize: 12, fontWeight: 600 };
const smallBtn: React.CSSProperties = { padding: '3px 8px', background: '#0ea5e9', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 12 };
