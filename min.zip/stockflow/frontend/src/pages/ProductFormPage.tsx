import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../api';

const EMPTY_FORM = { name: '', sku: '', description: '', quantityOnHand: 0, costPrice: '', sellingPrice: '', lowStockThreshold: '' };

export default function ProductFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isEdit) {
      api.get(`/products/${id}`).then(r => {
        const p = r.data;
        setForm({
          name: p.name || '',
          sku: p.sku || '',
          description: p.description || '',
          quantityOnHand: p.quantityOnHand ?? 0,
          costPrice: p.costPrice != null ? String(p.costPrice) : '',
          sellingPrice: p.sellingPrice != null ? String(p.sellingPrice) : '',
          lowStockThreshold: p.lowStockThreshold != null ? String(p.lowStockThreshold) : '',
        });
      });
    }
  }, [id, isEdit]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: name === 'quantityOnHand' ? Number(value) : value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const payload = {
      name: form.name,
      sku: form.sku,
      description: form.description || null,
      quantityOnHand: Number(form.quantityOnHand),
      costPrice: form.costPrice !== '' ? Number(form.costPrice) : null,
      sellingPrice: form.sellingPrice !== '' ? Number(form.sellingPrice) : null,
      lowStockThreshold: form.lowStockThreshold !== '' ? Number(form.lowStockThreshold) : null,
    };
    try {
      if (isEdit) {
        await api.put(`/products/${id}`, payload);
      } else {
        await api.post('/products', payload);
      }
      navigate('/products');
    } catch (err: any) {
      const msg = err.response?.data?.message || err.response?.data?.details?.name || 'Save failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 560 }}>
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 24 }}>{isEdit ? 'Edit Product' : 'New Product'}</h2>
      {error && <div style={errorStyle}>{error}</div>}
      <form onSubmit={handleSubmit} style={formStyle}>
        <div style={row}>
          <div style={field}>
            <label style={label}>Name *</label>
            <input style={input} name="name" value={form.name} onChange={handleChange} required />
          </div>
          <div style={field}>
            <label style={label}>SKU *</label>
            <input style={input} name="sku" value={form.sku} onChange={handleChange} required />
          </div>
        </div>
        <div style={field}>
          <label style={label}>Description</label>
          <textarea style={{ ...input, resize: 'vertical', minHeight: 72 }} name="description" value={form.description} onChange={handleChange} />
        </div>
        <div style={row}>
          <div style={field}>
            <label style={label}>Quantity on Hand *</label>
            <input style={input} type="number" name="quantityOnHand" value={form.quantityOnHand} onChange={handleChange} min={0} required />
          </div>
          <div style={field}>
            <label style={label}>Low Stock Threshold</label>
            <input style={input} type="number" name="lowStockThreshold" value={form.lowStockThreshold} onChange={handleChange} min={0} placeholder="Use global default" />
          </div>
        </div>
        <div style={row}>
          <div style={field}>
            <label style={label}>Cost Price</label>
            <input style={input} type="number" step="0.01" name="costPrice" value={form.costPrice} onChange={handleChange} min={0} />
          </div>
          <div style={field}>
            <label style={label}>Selling Price</label>
            <input style={input} type="number" step="0.01" name="sellingPrice" value={form.sellingPrice} onChange={handleChange} min={0} />
          </div>
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
          <button style={btnPrimary} type="submit" disabled={loading}>
            {loading ? 'Saving...' : isEdit ? 'Update Product' : 'Create Product'}
          </button>
          <button style={btnSecondary} type="button" onClick={() => navigate('/products')}>Cancel</button>
        </div>
      </form>
    </div>
  );
}

const formStyle: React.CSSProperties = { background: '#fff', borderRadius: 10, padding: 28, boxShadow: '0 1px 4px rgba(0,0,0,0.06)', display: 'flex', flexDirection: 'column', gap: 16 };
const row: React.CSSProperties = { display: 'flex', gap: 16 };
const field: React.CSSProperties = { flex: 1, display: 'flex', flexDirection: 'column' };
const label: React.CSSProperties = { fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4 };
const input: React.CSSProperties = { display: 'block', padding: '9px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, width: '100%', boxSizing: 'border-box' };
const btnPrimary: React.CSSProperties = { padding: '11px 24px', background: '#0ea5e9', color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer' };
const btnSecondary: React.CSSProperties = { padding: '11px 24px', background: '#f1f5f9', color: '#374151', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer' };
const errorStyle: React.CSSProperties = { background: '#fef2f2', border: '1px solid #fca5a5', color: '#b91c1c', borderRadius: 8, padding: '10px 14px', marginBottom: 16, fontSize: 14 };
