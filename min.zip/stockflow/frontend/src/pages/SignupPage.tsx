import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api';
import { useAuth } from '../AuthContext';

export default function SignupPage() {
  const [form, setForm] = useState({ email: '', password: '', confirmPassword: '', organizationName: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    setLoading(true);
    try {
      const { data } = await api.post('/auth/signup', {
        email: form.email,
        password: form.password,
        organizationName: form.organizationName,
      });
      login(data);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8, color: '#1e293b' }}>📦 StockFlow</h1>
        <p style={{ color: '#64748b', marginBottom: 24 }}>Create your account</p>
        {error && <div style={errorStyle}>{error}</div>}
        <form onSubmit={handleSubmit}>
          <label style={labelStyle}>Email</label>
          <input style={inputStyle} type="email" name="email" value={form.email} onChange={handleChange} required />
          <label style={labelStyle}>Organization Name</label>
          <input style={inputStyle} type="text" name="organizationName" value={form.organizationName} onChange={handleChange} required />
          <label style={labelStyle}>Password</label>
          <input style={inputStyle} type="password" name="password" value={form.password} onChange={handleChange} required minLength={8} />
          <label style={labelStyle}>Confirm Password</label>
          <input style={inputStyle} type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} required />
          <button style={btnStyle} type="submit" disabled={loading}>
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>
        <p style={{ marginTop: 16, textAlign: 'center', fontSize: 14, color: '#64748b' }}>
          Have an account? <Link to="/login" style={{ color: '#0ea5e9' }}>Sign in</Link>
        </p>
      </div>
    </div>
  );
}

const pageStyle: React.CSSProperties = { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f1f5f9' };
const cardStyle: React.CSSProperties = { background: '#fff', borderRadius: 12, padding: 40, width: 420, boxShadow: '0 4px 24px rgba(0,0,0,0.08)' };
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4, marginTop: 12 };
const inputStyle: React.CSSProperties = { display: 'block', width: '100%', padding: '10px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, boxSizing: 'border-box' };
const btnStyle: React.CSSProperties = { display: 'block', width: '100%', marginTop: 20, padding: '12px', background: '#0ea5e9', color: '#fff', border: 'none', borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: 'pointer', boxSizing: 'border-box' };
const errorStyle: React.CSSProperties = { background: '#fef2f2', border: '1px solid #fca5a5', color: '#b91c1c', borderRadius: 8, padding: '10px 14px', marginBottom: 12, fontSize: 14 };
