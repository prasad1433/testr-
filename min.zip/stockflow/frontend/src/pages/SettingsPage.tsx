import React, { useEffect, useState } from 'react';
import api from '../api';

export default function SettingsPage() {
  const [threshold, setThreshold] = useState<number>(5);
  const [orgName, setOrgName] = useState('');
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/settings').then(r => {
      setThreshold(r.data.defaultLowStockThreshold);
      setOrgName(r.data.organizationName);
    }).finally(() => setLoading(false));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.put('/settings', { defaultLowStockThreshold: threshold });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  if (loading) return <div style={{ color: '#64748b', padding: 20 }}>Loading...</div>;

  return (
    <div style={{ maxWidth: 480 }}>
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 24 }}>Settings</h2>
      <div style={card}>
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: '#64748b', marginBottom: 2 }}>Organization</div>
          <div style={{ fontWeight: 600, fontSize: 16 }}>{orgName}</div>
        </div>
        <form onSubmit={handleSubmit}>
          <label style={labelStyle}>Default Low Stock Threshold</label>
          <p style={{ fontSize: 12, color: '#64748b', marginBottom: 8 }}>
            Products without a custom threshold will use this value. A product is "low stock" when its quantity is at or below this number.
          </p>
          <input
            style={inputStyle}
            type="number"
            min={0}
            value={threshold}
            onChange={e => setThreshold(Number(e.target.value))}
            required
          />
          <button style={btnStyle} type="submit">Save Settings</button>
          {saved && <span style={{ color: '#16a34a', fontSize: 13, marginLeft: 12 }}>✓ Saved</span>}
        </form>
      </div>
    </div>
  );
}

const card: React.CSSProperties = { background: '#fff', borderRadius: 10, padding: 28, boxShadow: '0 1px 4px rgba(0,0,0,0.06)' };
const labelStyle: React.CSSProperties = { display: 'block', fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4 };
const inputStyle: React.CSSProperties = { width: 120, padding: '9px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, display: 'block', marginBottom: 16 };
const btnStyle: React.CSSProperties = { padding: '10px 22px', background: '#0ea5e9', color: '#fff', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer' };
