import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import { Dashboard, Product } from '../types';

export default function DashboardPage() {
  const [data, setData] = useState<Dashboard | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard').then(r => setData(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ padding: 20, color: '#64748b' }}>Loading...</div>;

  return (
    <div>
      <h2 style={h2}>Dashboard</h2>
      <div style={cardRow}>
        <div style={card}>
          <div style={cardLabel}>Total Products</div>
          <div style={cardValue}>{data?.totalProducts ?? 0}</div>
        </div>
        <div style={card}>
          <div style={cardLabel}>Total Units in Stock</div>
          <div style={cardValue}>{data?.totalQuantityOnHand ?? 0}</div>
        </div>
        <div style={{ ...card, borderColor: data && data.lowStockItems.length > 0 ? '#fca5a5' : '#e2e8f0' }}>
          <div style={cardLabel}>Low Stock Items</div>
          <div style={{ ...cardValue, color: data && data.lowStockItems.length > 0 ? '#dc2626' : '#1e293b' }}>
            {data?.lowStockItems.length ?? 0}
          </div>
        </div>
      </div>

      <div style={{ marginTop: 32 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ fontSize: 17, fontWeight: 600 }}>Low Stock Items</h3>
          <Link to="/products" style={{ fontSize: 13, color: '#0ea5e9', textDecoration: 'none' }}>View all products →</Link>
        </div>
        {data?.lowStockItems.length === 0 ? (
          <div style={{ color: '#64748b', fontSize: 14, padding: '24px', background: '#f8fafc', borderRadius: 8, textAlign: 'center' }}>
            🎉 No low stock items
          </div>
        ) : (
          <table style={tableStyle}>
            <thead>
              <tr style={thRowStyle}>
                <th style={th}>Name</th>
                <th style={th}>SKU</th>
                <th style={th}>Qty on Hand</th>
                <th style={th}>Threshold</th>
              </tr>
            </thead>
            <tbody>
              {data?.lowStockItems.map((p: Product) => (
                <tr key={p.id} style={trStyle}>
                  <td style={td}><Link to={`/products/${p.id}/edit`} style={{ color: '#0ea5e9', textDecoration: 'none' }}>{p.name}</Link></td>
                  <td style={td}><code style={{ fontSize: 12, background: '#f1f5f9', padding: '2px 6px', borderRadius: 4 }}>{p.sku}</code></td>
                  <td style={{ ...td, color: '#dc2626', fontWeight: 600 }}>{p.quantityOnHand}</td>
                  <td style={td}>{p.lowStockThreshold ?? 'default'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

const h2: React.CSSProperties = { fontSize: 24, fontWeight: 700, marginBottom: 24 };
const cardRow: React.CSSProperties = { display: 'flex', gap: 16, flexWrap: 'wrap' };
const card: React.CSSProperties = { background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: '20px 28px', minWidth: 160, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' };
const cardLabel: React.CSSProperties = { fontSize: 13, color: '#64748b', marginBottom: 6 };
const cardValue: React.CSSProperties = { fontSize: 32, fontWeight: 700 };
const tableStyle: React.CSSProperties = { width: '100%', borderCollapse: 'collapse', background: '#fff', borderRadius: 8, overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.04)' };
const thRowStyle: React.CSSProperties = { background: '#f8fafc' };
const th: React.CSSProperties = { padding: '12px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px' };
const trStyle: React.CSSProperties = { borderTop: '1px solid #f1f5f9' };
const td: React.CSSProperties = { padding: '12px 16px', fontSize: 14 };
