# Install npm packages for stockflow frontend via PowerShell (bypasses NTLM proxy auth)
# Uses /package/latest endpoint (tiny ~10KB) instead of full packument (~5MB)
$frontendDir = "c:\copy\stockflow\frontend"
$registry    = "https://registry.npmjs.org"   # for metadata (JSON)
$cdnRegistry = "https://registry.yarnpkg.com"  # for tarballs (proxy allows this)
$nm          = Join-Path $frontendDir "node_modules"

$resolved  = [System.Collections.Generic.Dictionary[string,string]]::new()
$queue     = [System.Collections.Generic.Queue[object]]::new()
$failed    = [System.Collections.Generic.List[string]]::new()
$installed = 0

# Pre-pin versions where 'latest' tag may not satisfy the constraint
# (avoids fetching huge multi-MB packuments for these)
$pins = @{
    "react"                = "18.3.1"
    "react-dom"            = "18.3.1"
    "react-router-dom"     = "6.30.1"
    "axios"                = "1.7.9"
    "typescript"           = "5.9.3"
    "@types/react"         = "18.3.23"
    "@types/react-dom"     = "18.3.7"
    "@types/node"          = "20.17.46"
    "vite"                 = "6.4.2"
    "@vitejs/plugin-react" = "4.7.0"
}

function Resolve-Version($name, $spec) {
    if ($pins.ContainsKey($name))                   { return $pins[$name] }
    if ($spec -match "^\d+\.\d+\.\d+(-\S+)?$")     { return $spec }  # exact
    if ([string]::IsNullOrWhiteSpace($spec) -or $spec -eq "*" -or $spec -eq "latest") {
        $spec = "latest"
    }
    # Determine required major from spec
    $reqMajor = $null
    if ($spec -match "^\^(\d+)\.")  { $reqMajor = [int]$Matches[1] }
    elseif ($spec -match "^~(\d+)\.") { $reqMajor = [int]$Matches[1] }
    elseif ($spec -match "^(\d+)$")   { $reqMajor = [int]$Matches[1] }

    try {
        # Try 'latest' first — tiny response
        $latest = Invoke-RestMethod "$registry/$name/latest" -TimeoutSec 30 -EA Stop
        $latVer   = $latest.version
        $latMajor = [int]($latVer -split '\.')[0]
        if ($reqMajor -eq $null -or $reqMajor -eq $latMajor) { return $latVer }

        # Major mismatch — use abbreviated packument (smaller than full)
        $abbrHeaders = @{ Accept = 'application/vnd.npm.install-v1+json' }
        $abbrMeta = Invoke-RestMethod "$registry/$name" -Headers $abbrHeaders -TimeoutSec 60 -EA Stop
        $best = $abbrMeta.versions.PSObject.Properties.Name |
            Where-Object { $_ -notmatch "-" -and $_ -match "^$reqMajor\." } |
            Sort-Object { try { $p=$_ -split '\.'; [long]($p[0])*1e6+[long]($p[1])*1e3+[long]($p[2]) } catch { 0 } } |
            Select-Object -Last 1
        if ($best) { return $best }
        return $latVer
    } catch { return $null }
}

function Skip-Pkg($name) {
    if ($name -match "fsevents")                                    { return $true }
    if ($name -match "-(linux|darwin|android|freebsd|wasm32|wasm64)-") { return $true }
    if ($name -match "-win32-(ia32|arm64)")                          { return $true }
    return $false
}

function Enqueue-Dep($name, $spec) {
    if (Skip-Pkg $name)                     { return }
    if ($spec -match "^(file:|git\+|github:)") { return }
    if ($spec -eq "workspace:*")            { return }
    if (-not $resolved.ContainsKey($name))  {
        $queue.Enqueue([pscustomobject]@{ Name=$name; Spec=$spec })
    }
}

# ---------- Seed from package.json ----------
$pj = Get-Content "$frontendDir\package.json" -Raw | ConvertFrom-Json
if ($pj.dependencies)    { $pj.dependencies.PSObject.Properties    | ForEach-Object { Enqueue-Dep $_.Name $_.Value } }
if ($pj.devDependencies) { $pj.devDependencies.PSObject.Properties  | ForEach-Object { Enqueue-Dep $_.Name $_.Value } }

New-Item -ItemType Directory -Force -Path $nm | Out-Null
Write-Host "Starting install for stockflow frontend..."

while ($queue.Count -gt 0) {
    $item    = $queue.Dequeue()
    $pkgName = $item.Name
    $spec    = $item.Spec

    if ($resolved.ContainsKey($pkgName)) { continue }
    if (Skip-Pkg $pkgName)               { $resolved[$pkgName]="skip"; continue }

    $version = Resolve-Version $pkgName $spec
    if (-not $version) {
        $failed.Add("VER:$pkgName@$spec"); Write-Warning "No version for $pkgName @ $spec"; continue
    }
    $resolved[$pkgName] = $version

    $targetDir = Join-Path $nm $pkgName
    if (-not (Test-Path "$targetDir\package.json")) {
        $basename = if ($pkgName -match "^@[^/]+/(.+)$") { $Matches[1] } else { $pkgName }
        $url  = "$cdnRegistry/$pkgName/-/$basename-$version.tgz"
        $tmp  = [IO.Path]::GetTempFileName() + ".tgz"
        try {
            Invoke-WebRequest $url -OutFile $tmp -UseBasicParsing -TimeoutSec 60 -EA Stop | Out-Null
            New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
            tar -xzf $tmp -C $targetDir --strip-components=1 2>&1 | Out-Null
            $installed++
            Write-Host "[$installed] $pkgName@$version"
        } catch {
            $failed.Add("DL:$pkgName@$version"); Write-Warning "Download failed $pkgName@$version"
        } finally { Remove-Item $tmp -EA SilentlyContinue }
    }

    # Enqueue transitive deps from the installed package.json (no extra HTTP needed)
    if (Test-Path "$targetDir\package.json") {
        try {
            $pkgMeta = Get-Content "$targetDir\package.json" -Raw | ConvertFrom-Json
            if ($pkgMeta.dependencies) {
                $pkgMeta.dependencies.PSObject.Properties | ForEach-Object { Enqueue-Dep $_.Name $_.Value }
            }
            # Also install optional dependencies (native binaries etc.)
            if ($pkgMeta.optionalDependencies) {
                $pkgMeta.optionalDependencies.PSObject.Properties | ForEach-Object { Enqueue-Dep $_.Name $_.Value }
            }
            if ($pkgMeta.peerDependencies) {
                $optional = @()
                if ($pkgMeta.peerDependenciesMeta) {
                    $optional = $pkgMeta.peerDependenciesMeta.PSObject.Properties |
                        Where-Object { $_.Value.optional -eq $true } | ForEach-Object { $_.Name }
                }
                $pkgMeta.peerDependencies.PSObject.Properties |
                    Where-Object { $_.Name -notin $optional } |
                    ForEach-Object { Enqueue-Dep $_.Name $_.Value }
            }
        } catch {}
    }
}

# ---------- Create .bin links ----------
Write-Host "`nCreating .bin links..."
New-Item -ItemType Directory -Force -Path "$nm\.bin" | Out-Null

function Add-BinLinks($dir, $relPath) {
    $pjPath = Join-Path $dir "package.json"
    if (-not (Test-Path $pjPath)) { return }
    try {
        $meta = Get-Content $pjPath -Raw | ConvertFrom-Json
        if (-not $meta.bin) { return }
        $binMap = if ($meta.bin -is [string]) {
            $shortName = $meta.name -replace '^@[^/]+/', ''
            @{ $shortName = $meta.bin }
        } else {
            $h = @{}; $meta.bin.PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value }; $h
        }
        foreach ($kv in $binMap.GetEnumerator()) {
            $cmd = "@echo off`r`nnode `"%~dp0\..\$relPath\$($kv.Value)`" %*"
            $cmd | Set-Content "$nm\.bin\$($kv.Key).cmd" -Encoding ASCII
        }
    } catch {}
}

# Flat packages
Get-ChildItem $nm -Directory | Where-Object { $_.Name -notlike "@*" } | ForEach-Object {
    Add-BinLinks $_.FullName $_.Name
}
# Scoped packages
Get-ChildItem $nm -Directory | Where-Object { $_.Name -like "@*" } | ForEach-Object {
    $scope = $_.Name
    Get-ChildItem $_.FullName -Directory | ForEach-Object {
        Add-BinLinks $_.FullName "$scope\$($_.Name)"
    }
}

Write-Host "`n=== Done: $installed installed, $($failed.Count) failed ==="
if ($failed.Count -gt 0) { Write-Host "Failed: $($failed -join ', ')" }
