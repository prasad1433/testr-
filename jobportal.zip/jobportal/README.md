# JobPortal Dashboard

A full-stack job portal with Spring Boot backend, React frontend, Docker containers, and AWS ECS deployment.

## Project Structure

```
jobportal/
├── backend/               # Spring Boot (Java 17)
│   ├── src/
│   │   └── main/java/com/jobportal/
│   │       ├── entity/        # JPA Entities
│   │       ├── repository/    # Spring Data repos
│   │       ├── service/       # Business logic
│   │       ├── controller/    # REST API
│   │       ├── dto/           # Request/Response DTOs
│   │       ├── security/      # JWT + Spring Security
│   │       ├── config/        # Security & CORS config
│   │       └── exception/     # Global error handling
│   └── Dockerfile
├── frontend/              # React + TypeScript + Tailwind
│   ├── src/
│   │   ├── pages/         # Dashboard, Jobs, Applications, etc.
│   │   ├── components/    # Layout with sidebar
│   │   ├── AuthContext.tsx
│   │   └── api.ts         # Axios instance
│   ├── nginx.conf
│   └── Dockerfile
├── docker-compose.yml     # Local dev with PostgreSQL
├── AWS_DEPLOYMENT.md      # Step-by-step AWS ECS deployment
└── .github/workflows/     # CI/CD pipeline
    └── deploy.yml
```

## Features

- **Auth**: JWT-based register/login with roles (Admin, Employer, Candidate)
- **Jobs**: Post, search (keyword/location/type), view, delete jobs
- **Applications**: Apply to jobs, track status (Pending → Hired)
- **Dashboard**: Stats with bar chart and pie chart (Employers/Admins)
- **Roles**: Employers post jobs; Candidates apply; Admins see all stats

## Quick Start (Local)

### Prerequisites
- Docker & Docker Compose
- JDK 17 + Maven (for local dev without Docker)
- Node 20 + pnpm

### Run with Docker

```bash
cd jobportal

# Copy and edit env vars
cp .env.example .env

docker-compose up --build
```

- Frontend: http://localhost
- Backend API: http://localhost:8080/api
- Health: http://localhost:8080/actuator/health

### Run locally (dev mode)

```bash
# Start PostgreSQL
docker-compose up postgres -d

# Backend
cd backend
mvn spring-boot:run

# Frontend (new terminal)
cd frontend
pnpm install
pnpm dev
```

## API Endpoints

| Method | Endpoint                        | Auth     | Description              |
|--------|---------------------------------|----------|--------------------------|
| POST   | /api/auth/register              | Public   | Register                 |
| POST   | /api/auth/login                 | Public   | Login                    |
| GET    | /api/jobs/search                | Public   | Search jobs              |
| GET    | /api/jobs/{id}                  | Public   | Job detail               |
| POST   | /api/jobs                       | Employer | Post a job               |
| PUT    | /api/jobs/{id}                  | Employer | Update job               |
| DELETE | /api/jobs/{id}                  | Employer | Delete job               |
| POST   | /api/applications               | Candidate| Apply to job             |
| GET    | /api/applications/my            | Any      | My applications          |
| GET    | /api/applications/job/{jobId}   | Employer | Applications for a job   |
| PATCH  | /api/applications/{id}/status   | Employer | Update app status        |
| GET    | /api/dashboard/stats            | Admin/Employer | Dashboard stats  |

## AWS Deployment

See [AWS_DEPLOYMENT.md](AWS_DEPLOYMENT.md) for full ECS + RDS deployment guide.

CI/CD is handled by `.github/workflows/deploy.yml` — push to `main` builds images and deploys to ECS.
