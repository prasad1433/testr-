import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '../api'
import type { Job } from '../types'
import { useAuth } from '../AuthContext'
import toast from 'react-hot-toast'
import { MapPinIcon, BriefcaseIcon, CalendarIcon } from '@heroicons/react/24/outline'

export default function JobDetailPage() {
  const { id } = useParams()
  const [job, setJob] = useState<Job | null>(null)
  const [applying, setApplying] = useState(false)
  const [coverLetter, setCoverLetter] = useState('')
  const [resumeUrl, setResumeUrl] = useState('')
  const [showForm, setShowForm] = useState(false)
  const { user } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    api.get(`/jobs/${id}`).then(r => setJob(r.data))
  }, [id])

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault()
    setApplying(true)
    try {
      await api.post('/applications', { jobId: Number(id), coverLetter, resumeUrl })
      toast.success('Application submitted!')
      setShowForm(false)
    } catch {
      toast.error('Failed to apply. You may have already applied.')
    } finally {
      setApplying(false)
    }
  }

  if (!job) return <div className="text-center py-12 text-gray-500">Loading...</div>

  return (
    <div className="max-w-3xl mx-auto">
      <button onClick={() => navigate(-1)} className="text-blue-600 text-sm mb-4 hover:underline">← Back</button>
      <div className="bg-white rounded-xl shadow-sm p-8">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">{job.title}</h1>
            <p className="text-gray-600 mt-1">{job.company}</p>
          </div>
          <span className="text-sm bg-green-100 text-green-700 px-3 py-1 rounded-full">{job.status}</span>
        </div>

        <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-6">
          {job.location && <span className="flex items-center gap-1"><MapPinIcon className="w-4 h-4" />{job.location}</span>}
          {job.jobType && <span className="flex items-center gap-1"><BriefcaseIcon className="w-4 h-4" />{job.jobType.replace('_', ' ')}</span>}
          {job.deadline && <span className="flex items-center gap-1"><CalendarIcon className="w-4 h-4" />Deadline: {new Date(job.deadline).toLocaleDateString()}</span>}
        </div>

        {(job.salaryMin || job.salaryMax) && (
          <p className="text-blue-600 font-semibold mb-4">${job.salaryMin?.toLocaleString()} – ${job.salaryMax?.toLocaleString()} /yr</p>
        )}

        <div className="prose prose-sm max-w-none text-gray-700 mb-6 whitespace-pre-wrap">{job.description}</div>

        {user?.role === 'CANDIDATE' && (
          <div>
            {!showForm ? (
              <button
                onClick={() => setShowForm(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
              >
                Apply Now
              </button>
            ) : (
              <form onSubmit={handleApply} className="border rounded-xl p-6 space-y-4 bg-gray-50">
                <h3 className="font-semibold text-gray-800">Submit Application</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Resume URL</label>
                  <input
                    type="url"
                    value={resumeUrl}
                    onChange={e => setResumeUrl(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Cover Letter</label>
                  <textarea
                    rows={4}
                    value={coverLetter}
                    onChange={e => setCoverLetter(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Tell the employer why you're a great fit..."
                  />
                </div>
                <div className="flex gap-3">
                  <button type="submit" disabled={applying}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-60">
                    {applying ? 'Submitting...' : 'Submit'}
                  </button>
                  <button type="button" onClick={() => setShowForm(false)}
                    className="border border-gray-300 px-5 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50">
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
