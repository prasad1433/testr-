import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api'
import type { Job, Page } from '../types'
import { MagnifyingGlassIcon, MapPinIcon, BriefcaseIcon } from '@heroicons/react/24/outline'

export default function JobsPage() {
  const [jobs, setJobs] = useState<Job[]>([])
  const [totalPages, setTotalPages] = useState(0)
  const [page, setPage] = useState(0)
  const [keyword, setKeyword] = useState('')
  const [location, setLocation] = useState('')
  const [jobType, setJobType] = useState('')
  const [loading, setLoading] = useState(false)

  const fetchJobs = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(page), size: '9' })
      if (keyword) params.set('keyword', keyword)
      if (location) params.set('location', location)
      if (jobType) params.set('jobType', jobType)
      const { data } = await api.get<Page<Job>>(`/jobs/search?${params}`)
      setJobs(data.content)
      setTotalPages(data.totalPages)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchJobs() }, [page])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setPage(0)
    fetchJobs()
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Browse Jobs</h1>

      {/* Search bar */}
      <form onSubmit={handleSearch} className="bg-white rounded-xl shadow-sm p-4 mb-6 flex flex-wrap gap-3">
        <div className="flex-1 min-w-[180px] relative">
          <MagnifyingGlassIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={keyword}
            onChange={e => setKeyword(e.target.value)}
            placeholder="Job title or keyword"
            className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div className="flex-1 min-w-[150px] relative">
          <MapPinIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={location}
            onChange={e => setLocation(e.target.value)}
            placeholder="Location"
            className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <select
          value={jobType}
          onChange={e => setJobType(e.target.value)}
          className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Types</option>
          <option value="FULL_TIME">Full Time</option>
          <option value="PART_TIME">Part Time</option>
          <option value="CONTRACT">Contract</option>
          <option value="REMOTE">Remote</option>
        </select>
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
          Search
        </button>
      </form>

      {/* Jobs grid */}
      {loading ? (
        <div className="text-center py-12 text-gray-500">Loading...</div>
      ) : jobs.length === 0 ? (
        <div className="text-center py-12 text-gray-500">No jobs found.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {jobs.map(job => (
            <Link key={job.id} to={`/jobs/${job.id}`}
              className="bg-white rounded-xl shadow-sm p-5 hover:shadow-md transition-shadow border border-transparent hover:border-blue-200">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-800">{job.title}</h3>
                  <p className="text-sm text-gray-500">{job.company}</p>
                </div>
                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">{job.status}</span>
              </div>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                {job.location && (
                  <span className="flex items-center gap-1">
                    <MapPinIcon className="w-3 h-3" />{job.location}
                  </span>
                )}
                {job.jobType && (
                  <span className="flex items-center gap-1">
                    <BriefcaseIcon className="w-3 h-3" />{job.jobType.replace('_', ' ')}
                  </span>
                )}
              </div>
              {(job.salaryMin || job.salaryMax) && (
                <p className="text-sm text-blue-600 font-medium mt-2">
                  ${job.salaryMin?.toLocaleString()} – ${job.salaryMax?.toLocaleString()}
                </p>
              )}
            </Link>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-6">
          {Array.from({ length: totalPages }, (_, i) => (
            <button key={i} onClick={() => setPage(i)}
              className={`px-3 py-1 rounded-lg text-sm ${page === i ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border'}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
