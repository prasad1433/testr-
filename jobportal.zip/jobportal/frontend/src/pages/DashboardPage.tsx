import { useEffect, useState } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts'
import api from '../api'
import type { DashboardStats } from '../types'
import { useAuth } from '../AuthContext'

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444']

interface StatCardProps {
  label: string
  value: number
  color: string
}

function StatCard({ label, value, color }: StatCardProps) {
  return (
    <div className={`bg-white rounded-xl shadow-sm p-6 border-l-4 ${color}`}>
      <p className="text-sm text-gray-500">{label}</p>
      <p className="text-3xl font-bold text-gray-800 mt-1">{value.toLocaleString()}</p>
    </div>
  )
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const { user } = useAuth()

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(r => setStats(r.data))
      .catch(() => { /* candidate role won't have access - that's OK */ })
  }, [])

  const barData = stats ? [
    { name: 'Total Jobs', value: stats.totalJobs },
    { name: 'Active Jobs', value: stats.activeJobs },
    { name: 'Applications', value: stats.totalApplications },
    { name: 'Hired', value: stats.hiredCount },
  ] : []

  const pieData = stats ? [
    { name: 'Candidates', value: stats.totalCandidates },
    { name: 'Employers', value: stats.totalEmployers },
  ] : []

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-1">Dashboard</h1>
      <p className="text-gray-500 mb-6">Welcome back, {user?.fullName}!</p>

      {stats ? (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard label="Total Jobs" value={stats.totalJobs} color="border-blue-500" />
            <StatCard label="Active Jobs" value={stats.activeJobs} color="border-green-500" />
            <StatCard label="Applications" value={stats.totalApplications} color="border-yellow-500" />
            <StatCard label="Hired" value={stats.hiredCount} color="border-purple-500" />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-base font-semibold text-gray-700 mb-4">Overview</h2>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={barData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-base font-semibold text-gray-700 mb-4">User Distribution</h2>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                    {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Legend />
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-12 text-center">
          <p className="text-gray-500">
            {user?.role === 'CANDIDATE'
              ? 'Browse available jobs and track your applications below.'
              : 'Loading dashboard stats...'}
          </p>
        </div>
      )}
    </div>
  )
}
