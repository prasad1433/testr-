import { useEffect, useState } from 'react'
import api from '../api'
import type { Application, Page } from '../types'
import { useAuth } from '../AuthContext'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-yellow-100 text-yellow-700',
  REVIEWED: 'bg-blue-100 text-blue-700',
  SHORTLISTED: 'bg-purple-100 text-purple-700',
  REJECTED: 'bg-red-100 text-red-700',
  HIRED: 'bg-green-100 text-green-700',
}

export default function ApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([])
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  const { user } = useAuth()

  const fetchApplications = async () => {
    const { data } = await api.get<Page<Application>>(`/applications/my?page=${page}&size=10`)
    setApplications(data.content)
    setTotalPages(data.totalPages)
  }

  useEffect(() => { fetchApplications() }, [page])

  const updateStatus = async (id: number, status: string) => {
    try {
      await api.patch(`/applications/${id}/status`, { status })
      toast.success('Status updated')
      fetchApplications()
    } catch {
      toast.error('Failed to update status')
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">
        {user?.role === 'CANDIDATE' ? 'My Applications' : 'All Applications'}
      </h1>
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-600 text-xs uppercase">
            <tr>
              <th className="px-5 py-3 text-left">Job</th>
              <th className="px-5 py-3 text-left">Company</th>
              {user?.role !== 'CANDIDATE' && <th className="px-5 py-3 text-left">Candidate</th>}
              <th className="px-5 py-3 text-left">Applied</th>
              <th className="px-5 py-3 text-left">Status</th>
              {user?.role !== 'CANDIDATE' && <th className="px-5 py-3 text-left">Action</th>}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {applications.map(app => (
              <tr key={app.id} className="hover:bg-gray-50">
                <td className="px-5 py-4 font-medium text-gray-800">{app.jobTitle}</td>
                <td className="px-5 py-4 text-gray-500">{app.company}</td>
                {user?.role !== 'CANDIDATE' && (
                  <td className="px-5 py-4 text-gray-500">{app.candidateName}</td>
                )}
                <td className="px-5 py-4 text-gray-500">
                  {new Date(app.appliedAt).toLocaleDateString()}
                </td>
                <td className="px-5 py-4">
                  <span className={clsx('px-2 py-1 rounded-full text-xs font-medium', STATUS_COLORS[app.status])}>
                    {app.status}
                  </span>
                </td>
                {user?.role !== 'CANDIDATE' && (
                  <td className="px-5 py-4">
                    <select
                      value={app.status}
                      onChange={e => updateStatus(app.id, e.target.value)}
                      className="border border-gray-300 rounded px-2 py-1 text-xs"
                    >
                      <option value="PENDING">Pending</option>
                      <option value="REVIEWED">Reviewed</option>
                      <option value="SHORTLISTED">Shortlisted</option>
                      <option value="REJECTED">Rejected</option>
                      <option value="HIRED">Hired</option>
                    </select>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
        {applications.length === 0 && (
          <p className="text-center text-gray-500 py-10">No applications found.</p>
        )}
      </div>
      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          {Array.from({ length: totalPages }, (_, i) => (
            <button key={i} onClick={() => setPage(i)}
              className={`px-3 py-1 rounded-lg text-sm ${page === i ? 'bg-blue-600 text-white' : 'bg-white text-gray-600 border'}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
