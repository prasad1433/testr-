export interface User {
  email: string
  fullName: string
  role: 'ADMIN' | 'EMPLOYER' | 'CANDIDATE'
  token: string
}

export interface Job {
  id: number
  title: string
  description: string
  company: string
  location: string
  jobType: string
  experienceLevel: string
  salaryMin: number
  salaryMax: number
  status: string
  postedByName: string
  createdAt: string
  deadline: string
}

export interface Application {
  id: number
  jobId: number
  jobTitle: string
  company: string
  candidateName: string
  candidateEmail: string
  coverLetter: string
  resumeUrl: string
  status: string
  appliedAt: string
}

export interface DashboardStats {
  totalJobs: number
  activeJobs: number
  totalApplications: number
  pendingApplications: number
  totalUsers: number
  totalCandidates: number
  totalEmployers: number
  hiredCount: number
}

export interface Page<T> {
  content: T[]
  totalElements: number
  totalPages: number
  number: number
  size: number
}
