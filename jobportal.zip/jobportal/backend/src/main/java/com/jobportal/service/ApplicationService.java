package com.jobportal.service;

import com.jobportal.dto.ApplicationDto;
import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final UserRepository userRepository;

    public ApplicationDto.Response apply(ApplicationDto.CreateRequest request, String email) {
        User candidate = getUser(email);
        Job job = jobRepository.findById(request.getJobId())
                .orElseThrow(() -> new IllegalArgumentException("Job not found"));
        if (applicationRepository.existsByJobAndCandidate(job, candidate)) {
            throw new IllegalStateException("Already applied to this job");
        }
        Application application = Application.builder()
                .job(job)
                .candidate(candidate)
                .coverLetter(request.getCoverLetter())
                .resumeUrl(request.getResumeUrl())
                .build();
        return toResponse(applicationRepository.save(application));
    }

    public Page<ApplicationDto.Response> getMyApplications(String email, Pageable pageable) {
        User candidate = getUser(email);
        return applicationRepository.findByCandidate(candidate, pageable).map(this::toResponse);
    }

    public Page<ApplicationDto.Response> getApplicationsForJob(Long jobId, Pageable pageable) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new IllegalArgumentException("Job not found"));
        return applicationRepository.findByJob(job, pageable).map(this::toResponse);
    }

    public ApplicationDto.Response updateStatus(Long id, String status) {
        Application application = applicationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Application not found"));
        application.setStatus(Application.ApplicationStatus.valueOf(status.toUpperCase()));
        return toResponse(applicationRepository.save(application));
    }

    private ApplicationDto.Response toResponse(Application a) {
        return ApplicationDto.Response.builder()
                .id(a.getId())
                .jobId(a.getJob().getId())
                .jobTitle(a.getJob().getTitle())
                .company(a.getJob().getCompany())
                .candidateName(a.getCandidate().getFullName())
                .candidateEmail(a.getCandidate().getEmail())
                .coverLetter(a.getCoverLetter())
                .resumeUrl(a.getResumeUrl())
                .status(a.getStatus().name())
                .appliedAt(a.getAppliedAt())
                .build();
    }

    private User getUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }
}
