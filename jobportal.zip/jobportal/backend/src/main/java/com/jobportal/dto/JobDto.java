package com.jobportal.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDateTime;

public class JobDto {

    @Data
    public static class CreateRequest {
        @NotBlank
        private String title;

        @NotBlank
        private String description;

        @NotBlank
        private String company;

        private String location;
        private String jobType;
        private String experienceLevel;
        private Double salaryMin;
        private Double salaryMax;
        private LocalDateTime deadline;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private String title;
        private String description;
        private String company;
        private String location;
        private String jobType;
        private String experienceLevel;
        private Double salaryMin;
        private Double salaryMax;
        private String status;
        private String postedByName;
        private LocalDateTime createdAt;
        private LocalDateTime deadline;
    }
}
