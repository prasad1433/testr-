package com.jobportal.dto;

import lombok.*;
import java.time.LocalDateTime;

public class ApplicationDto {

    @Data
    public static class CreateRequest {
        private Long jobId;
        private String coverLetter;
        private String resumeUrl;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private Long jobId;
        private String jobTitle;
        private String company;
        private String candidateName;
        private String candidateEmail;
        private String coverLetter;
        private String resumeUrl;
        private String status;
        private LocalDateTime appliedAt;
    }

    @Data
    public static class StatusUpdateRequest {
        private String status;
    }
}
