package com.jobportal.service;

import com.jobportal.dto.DashboardStatsDto;
import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final JobRepository jobRepository;
    private final ApplicationRepository applicationRepository;
    private final UserRepository userRepository;

    public DashboardStatsDto getStats() {
        return DashboardStatsDto.builder()
                .totalJobs(jobRepository.count())
                .activeJobs(jobRepository.countByStatus(Job.JobStatus.ACTIVE))
                .totalApplications(applicationRepository.count())
                .pendingApplications(applicationRepository.countByStatus(Application.ApplicationStatus.PENDING))
                .totalUsers(userRepository.count())
                .totalCandidates(userRepository.findAll().stream()
                        .filter(u -> u.getRole() == User.Role.CANDIDATE).count())
                .totalEmployers(userRepository.findAll().stream()
                        .filter(u -> u.getRole() == User.Role.EMPLOYER).count())
                .hiredCount(applicationRepository.countByStatus(Application.ApplicationStatus.HIRED))
                .build();
    }
}
