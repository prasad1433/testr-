package com.jobportal.controller;

import com.jobportal.dto.ApplicationDto;
import com.jobportal.service.ApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/applications")
@RequiredArgsConstructor
public class ApplicationController {

    private final ApplicationService applicationService;

    @PostMapping
    public ResponseEntity<ApplicationDto.Response> apply(
            @RequestBody ApplicationDto.CreateRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(applicationService.apply(request, userDetails.getUsername()));
    }

    @GetMapping("/my")
    public ResponseEntity<Page<ApplicationDto.Response>> myApplications(
            @AuthenticationPrincipal UserDetails userDetails,
            Pageable pageable) {
        return ResponseEntity.ok(applicationService.getMyApplications(userDetails.getUsername(), pageable));
    }

    @GetMapping("/job/{jobId}")
    public ResponseEntity<Page<ApplicationDto.Response>> applicationsForJob(
            @PathVariable Long jobId,
            Pageable pageable) {
        return ResponseEntity.ok(applicationService.getApplicationsForJob(jobId, pageable));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApplicationDto.Response> updateStatus(
            @PathVariable Long id,
            @RequestBody ApplicationDto.StatusUpdateRequest request) {
        return ResponseEntity.ok(applicationService.updateStatus(id, request.getStatus()));
    }
}
