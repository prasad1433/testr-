package com.jobportal.service;

import com.jobportal.dto.JobDto;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class JobService {

    private final JobRepository jobRepository;
    private final UserRepository userRepository;

    public Page<JobDto.Response> searchJobs(String keyword, String location, String jobType, Pageable pageable) {
        return jobRepository.searchJobs(keyword, location, jobType, pageable)
                .map(this::toResponse);
    }

    public Page<JobDto.Response> getAllJobs(Pageable pageable) {
        return jobRepository.findAll(pageable).map(this::toResponse);
    }

    public JobDto.Response getJobById(Long id) {
        return jobRepository.findById(id).map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("Job not found"));
    }

    public JobDto.Response createJob(JobDto.CreateRequest request, String email) {
        User user = getUser(email);
        Job job = Job.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .company(request.getCompany())
                .location(request.getLocation())
                .jobType(request.getJobType())
                .experienceLevel(request.getExperienceLevel())
                .salaryMin(request.getSalaryMin())
                .salaryMax(request.getSalaryMax())
                .deadline(request.getDeadline())
                .postedBy(user)
                .build();
        return toResponse(jobRepository.save(job));
    }

    public JobDto.Response updateJob(Long id, JobDto.CreateRequest request, String email) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Job not found"));
        if (!job.getPostedBy().getEmail().equals(email)) {
            throw new AccessDeniedException("Not authorized");
        }
        job.setTitle(request.getTitle());
        job.setDescription(request.getDescription());
        job.setCompany(request.getCompany());
        job.setLocation(request.getLocation());
        job.setJobType(request.getJobType());
        job.setExperienceLevel(request.getExperienceLevel());
        job.setSalaryMin(request.getSalaryMin());
        job.setSalaryMax(request.getSalaryMax());
        job.setDeadline(request.getDeadline());
        return toResponse(jobRepository.save(job));
    }

    public void deleteJob(Long id, String email) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Job not found"));
        if (!job.getPostedBy().getEmail().equals(email)) {
            throw new AccessDeniedException("Not authorized");
        }
        jobRepository.delete(job);
    }

    public Page<JobDto.Response> getMyJobs(String email, Pageable pageable) {
        User user = getUser(email);
        return jobRepository.findByPostedBy(user, pageable).map(this::toResponse);
    }

    private JobDto.Response toResponse(Job job) {
        return JobDto.Response.builder()
                .id(job.getId())
                .title(job.getTitle())
                .description(job.getDescription())
                .company(job.getCompany())
                .location(job.getLocation())
                .jobType(job.getJobType())
                .experienceLevel(job.getExperienceLevel())
                .salaryMin(job.getSalaryMin())
                .salaryMax(job.getSalaryMax())
                .status(job.getStatus() != null ? job.getStatus().name() : null)
                .postedByName(job.getPostedBy() != null ? job.getPostedBy().getFullName() : null)
                .createdAt(job.getCreatedAt())
                .deadline(job.getDeadline())
                .build();
    }

    private User getUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    }
}
