package com.jobportal.dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsDto {
    private long totalJobs;
    private long activeJobs;
    private long totalApplications;
    private long pendingApplications;
    private long totalUsers;
    private long totalCandidates;
    private long totalEmployers;
    private long hiredCount;
}
