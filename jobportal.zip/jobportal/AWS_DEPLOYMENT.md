# AWS Deployment — Elastic Container Service (ECS) + RDS

## Architecture Overview

```
Internet
   │
   ▼
[ALB - Application Load Balancer]
   │                    │
   ▼                    ▼
[ECS Task: Frontend]  [ECS Task: Backend]
  (nginx:80)           (Spring Boot:8080)
                           │
                           ▼
                    [RDS PostgreSQL]
```

---

## Prerequisites

- AWS CLI configured (`aws configure`)
- Docker installed
- An AWS account with ECR, ECS, RDS, VPC access

---

## Step 1: Create ECR Repositories

```bash
aws ecr create-repository --repository-name jobportal/backend --region us-east-1
aws ecr create-repository --repository-name jobportal/frontend --region us-east-1
```

---

## Step 2: Build & Push Docker Images

```bash
# Authenticate Docker to ECR
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# Build and push backend
docker build -t jobportal/backend ./backend
docker tag jobportal/backend:latest <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/jobportal/backend:latest
docker push <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/jobportal/backend:latest

# Build and push frontend
docker build -t jobportal/frontend ./frontend
docker tag jobportal/frontend:latest <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/jobportal/frontend:latest
docker push <AWS_ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/jobportal/frontend:latest
```

---

## Step 3: Create RDS PostgreSQL Instance

```bash
aws rds create-db-instance \
  --db-instance-identifier jobportal-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 16.1 \
  --master-username postgres \
  --master-user-password <DB_PASSWORD> \
  --db-name jobportal \
  --allocated-storage 20 \
  --vpc-security-group-ids <SG_ID> \
  --db-subnet-group-name <SUBNET_GROUP> \
  --region us-east-1
```

---

## Step 4: Create ECS Cluster

```bash
aws ecs create-cluster --cluster-name jobportal-cluster --region us-east-1
```

---

## Step 5: Register Task Definitions

### Backend Task Definition (`ecs-backend-task.json`)

```json
{
  "family": "jobportal-backend",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::<ACCOUNT_ID>:role/ecsTaskExecutionRole",
  "containerDefinitions": [
    {
      "name": "backend",
      "image": "<ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/jobportal/backend:latest",
      "portMappings": [{ "containerPort": 8080 }],
      "environment": [
        { "name": "DB_URL", "value": "jdbc:postgresql://<RDS_ENDPOINT>:5432/jobportal" },
        { "name": "DB_USERNAME", "value": "postgres" }
      ],
      "secrets": [
        { "name": "DB_PASSWORD", "valueFrom": "arn:aws:ssm:us-east-1:<ACCOUNT_ID>:parameter/jobportal/db_password" },
        { "name": "JWT_SECRET", "valueFrom": "arn:aws:ssm:us-east-1:<ACCOUNT_ID>:parameter/jobportal/jwt_secret" }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/jobportal-backend",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "backend"
        }
      }
    }
  ]
}
```

```bash
aws ecs register-task-definition --cli-input-json file://ecs-backend-task.json
```

### Frontend Task Definition (`ecs-frontend-task.json`)

```json
{
  "family": "jobportal-frontend",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "executionRoleArn": "arn:aws:iam::<ACCOUNT_ID>:role/ecsTaskExecutionRole",
  "containerDefinitions": [
    {
      "name": "frontend",
      "image": "<ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/jobportal/frontend:latest",
      "portMappings": [{ "containerPort": 80 }],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/jobportal-frontend",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "frontend"
        }
      }
    }
  ]
}
```

```bash
aws ecs register-task-definition --cli-input-json file://ecs-frontend-task.json
```

---

## Step 6: Create ECS Services

```bash
# Backend service
aws ecs create-service \
  --cluster jobportal-cluster \
  --service-name jobportal-backend \
  --task-definition jobportal-backend \
  --desired-count 1 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[<SUBNET_IDS>],securityGroups=[<SG_ID>],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=<BACKEND_TG_ARN>,containerName=backend,containerPort=8080" \
  --region us-east-1

# Frontend service
aws ecs create-service \
  --cluster jobportal-cluster \
  --service-name jobportal-frontend \
  --task-definition jobportal-frontend \
  --desired-count 1 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[<SUBNET_IDS>],securityGroups=[<SG_ID>],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=<FRONTEND_TG_ARN>,containerName=frontend,containerPort=80" \
  --region us-east-1
```

---

## Step 7: Store Secrets in AWS SSM Parameter Store

```bash
aws ssm put-parameter \
  --name "/jobportal/db_password" \
  --value "<DB_PASSWORD>" \
  --type SecureString \
  --region us-east-1

aws ssm put-parameter \
  --name "/jobportal/jwt_secret" \
  --value "<JWT_SECRET_BASE64>" \
  --type SecureString \
  --region us-east-1
```

---

## Environment Variables Reference

| Variable         | Description                        | Default                  |
|------------------|------------------------------------|--------------------------|
| `DB_URL`         | JDBC PostgreSQL URL                | `jdbc:postgresql://...`  |
| `DB_USERNAME`    | Database username                  | `postgres`               |
| `DB_PASSWORD`    | Database password (use SSM)        | —                        |
| `JWT_SECRET`     | Base64-encoded 256-bit secret      | —                        |
| `JWT_EXPIRATION` | Token expiry in milliseconds       | `86400000` (24h)         |
