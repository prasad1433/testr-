$frontendDir = "c:\copy\marketode-main\candidate-project-fullstack\candidate-project\frontend"
Set-Location $frontendDir

$lines = Get-Content "pnpm-lock.yaml"
$inPkg=$false; $pkgs=@{}; $cur=$null; $curV=$null; $curCpu=@(); $curOs=@()

foreach ($l in $lines) {
    if ($l -eq "packages:") {$inPkg=$true;continue}
    if ($inPkg -and $l -eq "snapshots:") {break}
    if (-not $inPkg) {continue}
    # Unscoped package: 2 spaces + no @ no ' at start, then name@version:
    if ($l -match "^  ([a-zA-Z0-9][^\s@]*)@([^\s(:]+):\s*$") {
        if ($cur) { $pkgs[$cur]=@{v=$curV;cpu=$curCpu;os=$curOs} }
        $cur=$Matches[1]; $curV=$Matches[2]; $curCpu=@(); $curOs=@()
    } elseif ($cur -and $l -match "^\s+cpu:\s*\[([^\]]+)\]") {
        $curCpu=$Matches[1]-split',\s*'|ForEach-Object{$_.Trim().Trim("'")}
    } elseif ($cur -and $l -match "^\s+os:\s*\[([^\]]+)\]") {
        $curOs=$Matches[1]-split',\s*'|ForEach-Object{$_.Trim().Trim("'")}
    }
}
if ($cur) { $pkgs[$cur]=@{v=$curV;cpu=$curCpu;os=$curOs} }

$toInstall = $pkgs.GetEnumerator() | Where-Object {
    $cpu=$_.Value.cpu; $os=$_.Value.os
    $cpuOk = ($cpu.Count -eq 0) -or ($cpu -contains "x64")
    $osOk  = ($os.Count -eq 0)  -or ($os -contains "win32")
    $cpuOk -and $osOk
}

Write-Host "Found $($toInstall.Count) unscoped packages to install (win32-x64)..."
$i=0; $total=@($toInstall).Count; $failed=@()

foreach ($e in $toInstall) {
    $i++
    $name=$e.Key; $ver=$e.Value.v
    $targetDir="node_modules\$name"
    if (Test-Path "$targetDir\package.json") { Write-Host "[$i/$total] SKIP $name"; continue }
    $url="https://registry.npmjs.org/$name/-/$name-$ver.tgz"
    $tmp=[System.IO.Path]::GetTempFileName()+".tgz"
    try {
        Write-Host "[$i/$total] $name@$ver"
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -ErrorAction Stop | Out-Null
        New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
        & tar -xzf $tmp -C $targetDir --strip-components=1 2>&1 | Out-Null
        Write-Host "[$i/$total] OK"
    } catch {
        Write-Warning "[$i/$total] FAIL $name@$ver : $($_.Exception.Message)"
        $failed += $name
    } finally { Remove-Item $tmp -ErrorAction SilentlyContinue }
}

Write-Host "=== Done: $($total - $failed.Count) ok, $($failed.Count) failed ==="
if ($failed) { $failed | ForEach-Object { Write-Warning "Failed: $_" } }
