import { useState } from 'react';
import { Modal, Button, TextField, Input, Label } from '@heroui/react';
import { api, CATEGORIES } from '../../lib/api';

export default function AddProductModal({ isOpen, onClose, onCreated }: any) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [price, setPrice] = useState('');
  const [error, setError] = useState<string | null>(null);

  const reset = () => {
    setName('');
    setDescription('');
    setCategory('');
    setPrice('');
    setError(null);
  };

  const handleSubmit = () => {
    api('/api/products', {
      method: 'POST',
      body: JSON.stringify({
        name,
        description,
        category,
        price: Number(price),
      }),
    })
      .then(() => {
        reset();
        onCreated();
      })
      .catch((e) => setError(e.message));
  };

  return (
    <Modal>
      <Modal.Backdrop isOpen={isOpen} onOpenChange={(open: boolean) => { if (!open) { reset(); onClose(); } }}>
        <Modal.Container size="lg">
          <Modal.Dialog>
            <Modal.CloseTrigger />
            <Modal.Header>
              <Modal.Heading>Add Product</Modal.Heading>
            </Modal.Header>
            <Modal.Body>
              <div className="flex flex-col gap-4">
                {error && <div className="text-danger text-sm">{error}</div>}
                <TextField isRequired>
                  <Label>Name</Label>
                  <Input value={name} onChange={(e: any) => setName(e.target.value)} />
                </TextField>
                <TextField isRequired>
                  <Label>Category</Label>
                  <select
                    className="border rounded p-2"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  >
                    <option value="">Select a category…</option>
                    {CATEGORIES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </TextField>
                <TextField>
                  <Label>Description</Label>
                  <Input value={description} onChange={(e: any) => setDescription(e.target.value)} />
                </TextField>
                <TextField isRequired>
                  <Label>Price</Label>
                  <Input type="number" value={price} onChange={(e: any) => setPrice(e.target.value)} />
                </TextField>
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="outline" onPress={() => { reset(); onClose(); }}>Cancel</Button>
              <Button variant="primary" onPress={handleSubmit}>Save</Button>
            </Modal.Footer>
          </Modal.Dialog>
        </Modal.Container>
      </Modal.Backdrop>
    </Modal>
  );
}
