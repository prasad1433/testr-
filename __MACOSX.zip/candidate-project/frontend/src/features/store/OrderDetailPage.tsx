import { useEffect, useState } from 'react';
import { Button, Card, Chip } from '@heroui/react';
import { api } from '../../lib/api';

export default function OrderDetailPage({ id, onBack, onChanged }: any) {
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const reload = () => {
    api(`/api/orders/${id}`)
      .then((data) => { setOrder(data); setError(null); })
      .catch((e) => setError(e.message));
  };

  useEffect(() => {
    reload();
  }, [id]);

  const handleCancel = () => {
    if (!window.confirm('Cancel this order? Stock will be restored.')) return;
    setBusy(true);
    api(`/api/orders/${id}/cancel`, { method: 'POST' })
      .then((data) => {
        setOrder(data);
        setError(null);
        onChanged?.();
      })
      .catch((e) => setError(e.message))
      .finally(() => setBusy(false));
  };

  if (!order) return null;

  return (
    <div className="max-w-2xl">
      <Button variant="ghost" onPress={onBack} className="mb-4">
        ← Back to orders
      </Button>

      {error && <div className="mb-3 text-danger text-sm">{error}</div>}

      <Card>
        <Card.Header className="flex justify-between items-center">
          <Card.Title>Order #{order.id}</Card.Title>
          <Chip size="sm" color={order.status === 'CREATED' ? 'success' : 'default'}>
            <Chip.Label>{order.status}</Chip.Label>
          </Chip>
        </Card.Header>
        <Card.Content className="flex flex-col gap-4">
          <div>
            <p className="text-sm text-default-500">Product</p>
            <p className="font-medium">{order.productName}</p>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-sm text-default-500">Quantity</p>
              <p className="font-medium">{order.quantity}</p>
            </div>
            <div>
              <p className="text-sm text-default-500">Unit price</p>
              <p className="font-medium">${Number(order.unitPrice ?? 0).toFixed(2)}</p>
            </div>
            <div>
              <p className="text-sm text-default-500">Total</p>
              <p className="font-medium">${Number(order.totalAmount ?? 0).toFixed(2)}</p>
            </div>
          </div>
          <div>
            <p className="text-sm text-default-500">Placed</p>
            <p>{order.createdAt ? new Date(order.createdAt).toLocaleString() : '—'}</p>
          </div>

          {order.status === 'CREATED' && (
            <div>
              <Button variant="outline" isDisabled={busy} onPress={handleCancel}>
                {busy ? 'Cancelling…' : 'Cancel order'}
              </Button>
            </div>
          )}
        </Card.Content>
      </Card>
    </div>
  );
}

