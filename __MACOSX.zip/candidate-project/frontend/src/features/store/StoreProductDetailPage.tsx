import { useEffect, useState } from 'react';
import { Button, Card, Chip, TextField, Input, Label } from '@heroui/react';
import { api } from '../../lib/api';

export default function StoreProductDetailPage({ id, currentUser, onBack, onOrderPlaced }: any) {
  const [product, setProduct] = useState<any>(null);
  const [quantity, setQuantity] = useState('1');
  const [error, setError] = useState<string | null>(null);
  const [placing, setPlacing] = useState(false);

  useEffect(() => {
    api(`/api/store/products/${id}`)
      .then((data) => { setProduct(data); setError(null); })
      .catch((e) => setError(e.message));
  }, [id]);

  const handlePlaceOrder = () => {
    const q = Number(quantity);
    if (!Number.isFinite(q) || q < 1) {
      setError('Quantity must be a positive integer.');
      return;
    }
    setPlacing(true);
    api('/api/orders', {
      method: 'POST',
      body: JSON.stringify({
        userId: currentUser.id,
        productId: product.id,
        quantity: q,
      }),
    })
      .then((order) => {
        setError(null);
        onOrderPlaced(order);
      })
      .catch((e) => setError(e.message))
      .finally(() => setPlacing(false));
  };

  if (!product) return null;

  return (
    <div className="max-w-2xl">
      <Button variant="ghost" onPress={onBack} className="mb-4">
        ← Back to shop
      </Button>

      {error && <div className="mb-3 text-danger text-sm">{error}</div>}

      <Card>
        <Card.Header className="flex justify-between items-center">
          <Card.Title>{product.name}</Card.Title>
          <Chip size="sm" color={product.inStock ? 'success' : 'danger'}>
            <Chip.Label>{product.inStock ? 'In stock' : 'Out of stock'}</Chip.Label>
          </Chip>
        </Card.Header>
        <Card.Content className="flex flex-col gap-4">
          <div>
            <p className="text-sm text-default-500">Category</p>
            <p>{product.category || '—'}</p>
          </div>
          <div>
            <p className="text-sm text-default-500">Description</p>
            <p>{product.description || '—'}</p>
          </div>
          <div>
            <p className="text-sm text-default-500">Price</p>
            <p className="font-medium">${Number(product.price ?? 0).toFixed(2)}</p>
          </div>

          <div className="flex items-end gap-3 pt-2 border-t">
            <TextField>
              <Label>Quantity</Label>
              <Input
                type="number"
                min={1}
                value={quantity}
                onChange={(e: any) => setQuantity(e.target.value)}
                disabled={!product.inStock}
              />
            </TextField>
            <Button
              variant="primary"
              isDisabled={!product.inStock || placing}
              onPress={handlePlaceOrder}
            >
              {placing ? 'Placing…' : 'Place Order'}
            </Button>
          </div>
          <p className="text-xs text-default-500">
            Ordering as <strong>{currentUser.name}</strong>
          </p>
        </Card.Content>
      </Card>
    </div>
  );
}

