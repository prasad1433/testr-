import { useEffect, useState } from 'react';
import { Button, Card, Chip } from '@heroui/react';
import { api } from '../../lib/api';

export default function CatalogPage({ onSelectProduct }: any) {
  const [products, setProducts] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api('/api/store/products')
      .then((data) => { setProducts(data); setError(null); })
      .catch((e) => setError(e.message));
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Shop</h1>
      {error && <div className="mb-3 text-danger text-sm">{error}</div>}

      {products.length === 0 ? (
        <p className="text-default-500">No products available.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((p) => (
            <Card key={p.id} className="flex flex-col">
              <Card.Header className="flex justify-between items-start">
                <Card.Title>{p.name}</Card.Title>
                <Chip size="sm" color={p.inStock ? 'success' : 'danger'}>
                  <Chip.Label>{p.inStock ? 'In stock' : 'Out of stock'}</Chip.Label>
                </Chip>
              </Card.Header>
              <Card.Content className="flex-1">
                <p className="text-sm text-default-500 mb-2">{p.category || '—'}</p>
                <p className="text-sm line-clamp-3">{p.description || ''}</p>
                <p className="mt-3 font-semibold">${Number(p.price ?? 0).toFixed(2)}</p>
              </Card.Content>
              <Card.Footer>
                <Button variant="primary" onPress={() => onSelectProduct(p.id)}>View</Button>
              </Card.Footer>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

