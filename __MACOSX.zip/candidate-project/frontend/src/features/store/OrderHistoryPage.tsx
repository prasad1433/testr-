import { useEffect, useState } from 'react';
import { Table, Chip } from '@heroui/react';
import { api } from '../../lib/api';

export default function OrderHistoryPage({ currentUser, onSelectOrder }: any) {
  const [orders, setOrders] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api(`/api/orders?userId=${currentUser.id}`)
      .then((data) => { setOrders(data); setError(null); })
      .catch((e) => setError(e.message));
  }, [currentUser.id]);

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">My Orders</h1>
      {error && <div className="mb-3 text-danger text-sm">{error}</div>}

      <Table>
        <Table.ScrollContainer>
          <Table.Content aria-label="Orders table">
            <Table.Header>
              <Table.Column isRowHeader>ORDER</Table.Column>
              <Table.Column>PRODUCT</Table.Column>
              <Table.Column>QTY</Table.Column>
              <Table.Column>TOTAL</Table.Column>
              <Table.Column>STATUS</Table.Column>
              <Table.Column>DATE</Table.Column>
            </Table.Header>
            <Table.Body>
              {orders.map((o) => (
                <Table.Row key={o.id} className="cursor-pointer" onAction={() => onSelectOrder(o.id)}>
                  <Table.Cell>#{o.id}</Table.Cell>
                  <Table.Cell className="font-medium">{o.productName}</Table.Cell>
                  <Table.Cell>{o.quantity}</Table.Cell>
                  <Table.Cell>${Number(o.totalAmount ?? 0).toFixed(2)}</Table.Cell>
                  <Table.Cell>
                    <Chip size="sm" color={o.status === 'CREATED' ? 'success' : 'default'}>
                      <Chip.Label>{o.status}</Chip.Label>
                    </Chip>
                  </Table.Cell>
                  <Table.Cell className="text-default-500">
                    {o.createdAt ? new Date(o.createdAt).toLocaleString() : '—'}
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table.Content>
        </Table.ScrollContainer>
      </Table>

      {orders.length === 0 && !error && (
        <p className="text-default-500 mt-4">You haven't placed any orders yet.</p>
      )}
    </div>
  );
}

