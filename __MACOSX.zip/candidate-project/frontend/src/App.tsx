import { useState } from 'react';
import AppLayout from './components/layout/AppLayout';
import ProductListPage from './features/products/ProductListPage';
import ProductDetailPage from './features/products/ProductDetailPage';
import CatalogPage from './features/store/CatalogPage';
import StoreProductDetailPage from './features/store/StoreProductDetailPage';
import OrderHistoryPage from './features/store/OrderHistoryPage';
import OrderDetailPage from './features/store/OrderDetailPage';

const USERS = [
  { id: 1, name: 'Alice Martin', email: 'alice@marketnode.com' },
  { id: 2, name: 'Bob Chen', email: 'bob@marketnode.com' },
  { id: 3, name: 'Carol Smith', email: 'carol@marketnode.com' },
];

type Mode = 'ims' | 'oms';
type Page =
  | 'ims:list'
  | 'ims:detail'
  | 'oms:catalog'
  | 'oms:product'
  | 'oms:orders'
  | 'oms:order';

function App() {
  const [mode, setMode] = useState<Mode>('ims');
  const [page, setPage] = useState<Page>('ims:list');
  const [selectedProductId, setSelectedProductId] = useState<any>(null);
  const [selectedOrderId, setSelectedOrderId] = useState<any>(null);
  const [currentUser, setCurrentUser] = useState(USERS[0]);

  const switchMode = (next: Mode) => {
    setMode(next);
    setSelectedProductId(null);
    setSelectedOrderId(null);
    setPage(next === 'ims' ? 'ims:list' : 'oms:catalog');
  };

  const navigate = (target: Page) => {
    setPage(target);
  };

  const content = (() => {
    // IMS
    if (page === 'ims:detail' && selectedProductId) {
      return (
        <ProductDetailPage
          id={selectedProductId}
          onBack={() => navigate('ims:list')}
        />
      );
    }
    if (mode === 'ims') {
      return (
        <ProductListPage
          onSelectProduct={(id: any) => {
            setSelectedProductId(id);
            navigate('ims:detail');
          }}
        />
      );
    }

    // OMS
    if (page === 'oms:product' && selectedProductId) {
      return (
        <StoreProductDetailPage
          id={selectedProductId}
          currentUser={currentUser}
          onBack={() => navigate('oms:catalog')}
          onOrderPlaced={(order: any) => {
            setSelectedOrderId(order.id);
            navigate('oms:order');
          }}
        />
      );
    }
    if (page === 'oms:orders') {
      return (
        <OrderHistoryPage
          currentUser={currentUser}
          onSelectOrder={(id: any) => {
            setSelectedOrderId(id);
            navigate('oms:order');
          }}
        />
      );
    }
    if (page === 'oms:order' && selectedOrderId) {
      return (
        <OrderDetailPage
          id={selectedOrderId}
          onBack={() => navigate('oms:orders')}
        />
      );
    }
    return (
      <CatalogPage
        onSelectProduct={(id: any) => {
          setSelectedProductId(id);
          navigate('oms:product');
        }}
      />
    );
  })();

  return (
    <AppLayout
      mode={mode}
      onModeChange={switchMode}
      page={page}
      onNavigate={navigate}
      currentUser={currentUser}
      users={USERS}
      onUserChange={setCurrentUser}
    >
      {content}
    </AppLayout>
  );
}

export default App;
