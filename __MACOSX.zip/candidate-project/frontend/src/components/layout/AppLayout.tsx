import TopBar from './TopBar';
import Sidebar from './Sidebar';

export default function AppLayout({
  children,
  mode,
  onModeChange,
  page,
  onNavigate,
  currentUser,
  users,
  onUserChange,
}: any) {
  return (
    <div className="flex flex-col h-screen">
      <TopBar
        mode={mode}
        onModeChange={onModeChange}
        currentUser={currentUser}
        users={users}
        onUserChange={onUserChange}
      />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar mode={mode} page={page} onNavigate={onNavigate} />
        <main className="flex-1 overflow-y-auto bg-default-100 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
