import { ListBox } from '@heroui/react';

const IMS_ITEMS = [
  { id: 'ims:list', label: 'Products', disabled: false },
  { id: 'ims:suppliers', label: 'Suppliers', disabled: true },
  { id: 'ims:warehouses', label: 'Warehouses', disabled: true },
  { id: 'ims:billing', label: 'Billing', disabled: true },
  { id: 'ims:reports', label: 'Reports', disabled: true },
];

const OMS_ITEMS = [
  { id: 'oms:catalog', label: 'Shop', disabled: false },
  { id: 'oms:orders', label: 'My Orders', disabled: false },
];

export default function Sidebar({ mode, page, onNavigate }: any) {
  const items = mode === 'oms' ? OMS_ITEMS : IMS_ITEMS;
  const title = mode === 'oms' ? 'Order Management' : 'Inventory Management';

  // The "active" key corresponds to the top-level nav item.
  // Detail pages map back to their parent.
  const activeMap: Record<string, string> = {
    'ims:list': 'ims:list',
    'ims:detail': 'ims:list',
    'oms:catalog': 'oms:catalog',
    'oms:product': 'oms:catalog',
    'oms:orders': 'oms:orders',
    'oms:order': 'oms:orders',
  };
  const active = activeMap[page] ?? items[0].id;

  return (
    <aside className="w-56 border-r border-default-200 bg-default-50 min-h-0 shrink-0">
      <div className="p-3">
        <p className="text-xs font-semibold text-default-400 uppercase tracking-wider px-2 mb-2">
          {title}
        </p>
        <ListBox
          aria-label="Navigation"
          selectionMode="single"
          selectedKeys={new Set([active])}
          disabledKeys={new Set(items.filter((i) => i.disabled).map((i) => i.id))}
          onAction={(key: any) => {
            const id = String(key);
            if (items.find((i) => i.id === id && !i.disabled)) {
              onNavigate(id);
            }
          }}
        >
          {items.map((item) => (
            <ListBox.Item key={item.id} id={item.id}>{item.label}</ListBox.Item>
          ))}
        </ListBox>
      </div>
    </aside>
  );
}
