param([int]$MaxConcurrent = 8)

$frontendDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $frontendDir
Write-Host "Working in: $frontendDir"

# ---- Parse pnpm-lock.yaml packages section ----
$lines = Get-Content "pnpm-lock.yaml"
$packages = [System.Collections.Generic.List[hashtable]]::new()
$inPackages = $false
$currentName = $null; $currentVer = $null; $currentCpu = @(); $currentOs = @()

foreach ($line in $lines) {
    if ($line -eq "packages:") { $inPackages = $true; continue }
    if ($inPackages -and $line -eq "snapshots:") { break }
    if (-not $inPackages) { continue }

    if ($line -match "^  '@?[^'\s]+':") {
        # Save previous
        if ($currentName) {
            $packages.Add(@{Name=$currentName; Version=$currentVer; Cpu=$currentCpu; Os=$currentOs})
        }
        $currentName = $null; $currentVer = $null; $currentCpu = @(); $currentOs = @()

        # Match: '  '@babel/core@7.29.0':'  or '  react@19.2.5:'
        if ($line -match "^  '?(@?[^@'\s]+)@([^('\s:]+)") {
            $currentName = $Matches[1]; $currentVer = $Matches[2]
        }
    }
    elseif ($currentName -and $line -match "^\s+cpu:\s*\[([^\]]+)\]") {
        $currentCpu = $Matches[1] -split ',\s*' | ForEach-Object { $_.Trim().Trim("'") }
    }
    elseif ($currentName -and $line -match "^\s+os:\s*\[([^\]]+)\]") {
        $currentOs = $Matches[1] -split ',\s*' | ForEach-Object { $_.Trim().Trim("'") }
    }
}
if ($currentName) { $packages.Add(@{Name=$currentName; Version=$currentVer; Cpu=$currentCpu; Os=$currentOs}) }

Write-Host "Found $($packages.Count) packages in lock file."

# ---- Filter to win32-x64 only ----
$toInstall = $packages | Where-Object {
    $cpu = $_.Cpu; $os = $_.Os
    $cpuOk = ($cpu.Count -eq 0) -or ($cpu -contains "x64")
    $osOk  = ($os.Count -eq 0)  -or ($os -contains "win32")
    $cpuOk -and $osOk
}
Write-Host "Packages to install (win32-x64): $($toInstall.Count)"

# ---- Create directories ----
New-Item -ItemType Directory -Force -Path "node_modules/.bin" | Out-Null

# ---- Download worker scriptblock ----
$downloadBlock = {
    param($pkgName, $version, $frontendDir)
    $targetDir = Join-Path $frontendDir "node_modules\$pkgName"
    if (Test-Path (Join-Path $targetDir "package.json")) { return "SKIP:$pkgName" }
    $basename = if ($pkgName -match "^@[^/]+/(.+)$") { $Matches[1] } else { $pkgName }
    $url = "https://registry.npmjs.org/$pkgName/-/$basename-$version.tgz"
    $tmp = [System.IO.Path]::GetTempFileName() + ".tgz"
    try {
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -ErrorAction Stop | Out-Null
        New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
        $result = & tar -xzf $tmp -C $targetDir --strip-components=1 2>&1
        return "OK:$pkgName@$version"
    } catch {
        return "FAIL:$pkgName@$version : $($_.Exception.Message)"
    } finally {
        Remove-Item $tmp -ErrorAction SilentlyContinue
    }
}

# ---- Parallel download with job queue ----
$jobs = [System.Collections.Generic.Queue[System.Management.Automation.Job]]::new()
$allJobs = @()
$idx = 0
$total = $toInstall.Count
$done = 0; $failed = @()

foreach ($pkg in $toInstall) {
    # Throttle
    while ($jobs.Count -ge $MaxConcurrent) {
        $j = $jobs.Dequeue()
        $out = $j | Wait-Job | Receive-Job
        Remove-Job $j
        $done++
        if ($out -match "^FAIL:") { $failed += $out; Write-Warning $out }
        elseif ($out -match "^SKIP:") { Write-Host "  SKIP $($out -replace '^SKIP:','')" }
        else { Write-Host "  OK   $($out -replace '^OK:','')" }
    }
    $idx++
    Write-Host "[$idx/$total] Queuing $($pkg.Name)@$($pkg.Version)"
    $j = Start-Job -ScriptBlock $downloadBlock -ArgumentList $pkg.Name, $pkg.Version, $frontendDir
    $jobs.Enqueue($j)
}

# Drain remaining jobs
while ($jobs.Count -gt 0) {
    $j = $jobs.Dequeue()
    $out = $j | Wait-Job | Receive-Job
    Remove-Job $j
    $done++
    if ($out -match "^FAIL:") { $failed += $out; Write-Warning $out }
    elseif ($out -match "^SKIP:") { Write-Host "  SKIP $($out -replace '^SKIP:','')" }
    else { Write-Host "  OK   $($out -replace '^OK:','')" }
}

Write-Host "`n=== Download complete: $done packages, $($failed.Count) failures ==="
if ($failed.Count -gt 0) { $failed | ForEach-Object { Write-Warning $_ } }

# ---- Create .bin links ----
Write-Host "`nCreating .bin links..."
Get-ChildItem "node_modules" -Directory -Recurse -Depth 1 | ForEach-Object {
    $pj = Join-Path $_.FullName "package.json"
    if (-not (Test-Path $pj)) { return }
    try {
        $meta = Get-Content $pj -Raw | ConvertFrom-Json
        if (-not $meta.bin) { return }
        $binMap = if ($meta.bin -is [string]) {
            @{ ($meta.name -replace '^@[^/]+/', '') = $meta.bin }
        } else {
            $h = @{}
            $meta.bin.PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value }
            $h
        }
        foreach ($kv in $binMap.GetEnumerator()) {
            $cmdFile = "node_modules/.bin/$($kv.Key).cmd"
            $relTarget = (Join-Path ($_.FullName -replace [regex]::Escape("$frontendDir\"), '') $kv.Value) -replace '\\', '/'
            "@echo off`r`nnode `"%~dp0\..\$relTarget`" %*" | Set-Content $cmdFile -Encoding ASCII
        }
    } catch {}
}

Write-Host "`nDone! Run: npm run dev"
