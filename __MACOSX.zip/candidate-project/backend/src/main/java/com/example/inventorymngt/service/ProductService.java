package com.example.inventorymngt.service;

import com.example.inventorymngt.entity.ProductCategory;
import com.example.inventorymngt.entity.ProductEntitiy;
import com.example.inventorymngt.entity.ProductRepo;
import com.example.inventorymngt.web.BadRequestException;
import com.example.inventorymngt.web.NotFoundException;
import com.example.inventorymngt.web.dto.ProductRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ProductService {

    private static final BigDecimal MAX_PRICE = new BigDecimal("99999.99");
    private static final int MAX_STOCK = 999_999;

    private final ProductRepo productRepo;

    public ProductService(ProductRepo productRepo) {
        this.productRepo = productRepo;
    }

    public List<ProductEntitiy> getProducts() {
        return productRepo.findAllByDeletedFalseOrderByIdAsc();
    }

    public ProductEntitiy getProduct(Long id) {
        return productRepo.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> new NotFoundException("Product " + id + " not found"));
    }

    /** Internal lookup that may return soft-deleted products (used by orders). */
    public ProductEntitiy getProductIncludingDeleted(Long id) {
        return productRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Product " + id + " not found"));
    }

    @Transactional
    public ProductEntitiy addProduct(ProductRequest req) {
        validateName(req.name);
        validatePrice(req.price);

        ProductEntitiy p = new ProductEntitiy();
        p.setName(req.name.trim());
        p.setDescription(trimDescription(req.description));
        p.setCategory(parseCategory(req.category, true));
        p.setPrice(req.price);
        p.setStock(0); // Always starts at zero per PRODUCT.md
        return productRepo.save(p);
    }

    @Transactional
    public ProductEntitiy updateProduct(Long id, ProductRequest req) {
        ProductEntitiy existing = getProduct(id);
        validateName(req.name);
        validatePrice(req.price);

        existing.setName(req.name.trim());
        existing.setDescription(trimDescription(req.description));
        existing.setCategory(parseCategory(req.category, true));
        existing.setPrice(req.price);
        // Stock intentionally not modified here.
        return productRepo.save(existing);
    }

    @Transactional
    public void deleteProduct(Long id) {
        ProductEntitiy existing = getProduct(id);
        // Soft delete to preserve order history references.
        existing.setDeleted(true);
        productRepo.save(existing);
    }

    @Transactional
    public ProductEntitiy adjustStock(Long id, Integer amount) {
        if (amount == null || amount == 0) {
            throw new BadRequestException("Stock adjustment amount must be a non-zero integer");
        }
        ProductEntitiy product = getProduct(id);
        int current = product.getStock() == null ? 0 : product.getStock();
        int next = current + amount;
        if (next < 0) {
            throw new BadRequestException("Stock cannot go below zero (current: " + current + ", requested change: " + amount + ")");
        }
        if (next > MAX_STOCK) {
            throw new BadRequestException("Stock cannot exceed " + MAX_STOCK);
        }
        product.setStock(next);
        return productRepo.save(product);
    }

    private void validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new BadRequestException("Name is required");
        }
        if (name.trim().length() > 255) {
            throw new BadRequestException("Name must be at most 255 characters");
        }
    }

    private void validatePrice(BigDecimal price) {
        if (price == null) {
            throw new BadRequestException("Price is required");
        }
        if (price.signum() < 0) {
            throw new BadRequestException("Price must be zero or positive");
        }
        if (price.scale() > 2) {
            throw new BadRequestException("Price must have at most 2 decimal places");
        }
        if (price.compareTo(MAX_PRICE) > 0) {
            throw new BadRequestException("Price must be at most " + MAX_PRICE);
        }
    }

    private String trimDescription(String description) {
        if (description == null) return null;
        if (description.length() > 2000) {
            throw new BadRequestException("Description must be at most 2000 characters");
        }
        return description;
    }

    private ProductCategory parseCategory(String value, boolean required) {
        if (value == null || value.trim().isEmpty()) {
            if (required) throw new BadRequestException("Category is required");
            return null;
        }
        try {
            return ProductCategory.fromString(value.trim());
        } catch (IllegalArgumentException ex) {
            throw new BadRequestException(ex.getMessage());
        }
    }
}
