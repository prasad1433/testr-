package com.example.inventorymngt.entity;

public enum ProductCategory {
    ELECTRONICS("Electronics"),
    CLOTHING("Clothing"),
    HOME_AND_GARDEN("Home & Garden"),
    SPORTS("Sports"),
    BOOKS("Books"),
    OTHER("Other");

    private final String label;

    ProductCategory(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static ProductCategory fromString(String value) {
        if (value == null) return null;
        for (ProductCategory c : values()) {
            if (c.name().equalsIgnoreCase(value) || c.label.equalsIgnoreCase(value)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Invalid category: " + value);
    }
}

