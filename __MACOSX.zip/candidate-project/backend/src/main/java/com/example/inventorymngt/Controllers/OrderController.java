package com.example.inventorymngt.Controllers;

import com.example.inventorymngt.service.OrderService;
import com.example.inventorymngt.web.dto.OrderDto;
import com.example.inventorymngt.web.dto.PlaceOrderRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public List<OrderDto> list(@RequestParam(required = false) Long userId) {
        return orderService.listOrders(userId).stream().map(OrderDto::from).toList();
    }

    @GetMapping("/{id}")
    public OrderDto get(@PathVariable Long id) {
        return OrderDto.from(orderService.getOrder(id));
    }

    @PostMapping
    public OrderDto place(@RequestBody PlaceOrderRequest req) {
        return OrderDto.from(orderService.placeOrder(req));
    }

    @PostMapping("/{id}/cancel")
    public OrderDto cancel(@PathVariable Long id) {
        return OrderDto.from(orderService.cancelOrder(id));
    }
}

