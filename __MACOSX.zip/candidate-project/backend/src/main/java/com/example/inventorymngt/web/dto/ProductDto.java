package com.example.inventorymngt.web.dto;

import com.example.inventorymngt.entity.ProductCategory;
import com.example.inventorymngt.entity.ProductEntitiy;

import java.math.BigDecimal;

public class ProductDto {
    public Long id;
    public String name;
    public String description;
    public String category;
    public BigDecimal price;
    public Integer stock;

    public static ProductDto from(ProductEntitiy p) {
        ProductDto d = new ProductDto();
        d.id = p.getId();
        d.name = p.getName();
        d.description = p.getDescription();
        ProductCategory c = p.getCategory();
        d.category = c == null ? null : c.getLabel();
        d.price = p.getPrice();
        d.stock = p.getStock();
        return d;
    }
}

