package com.example.inventorymngt.web.dto;

import com.example.inventorymngt.entity.ProductCategory;
import com.example.inventorymngt.entity.ProductEntitiy;

import java.math.BigDecimal;

/**
 * Storefront product projection: never exposes exact stock counts,
 * only an in-stock indicator (per PRODUCT.md).
 */
public class StoreProductDto {
    public Long id;
    public String name;
    public String description;
    public String category;
    public BigDecimal price;
    public boolean inStock;

    public static StoreProductDto from(ProductEntitiy p) {
        StoreProductDto d = new StoreProductDto();
        d.id = p.getId();
        d.name = p.getName();
        d.description = p.getDescription();
        ProductCategory c = p.getCategory();
        d.category = c == null ? null : c.getLabel();
        d.price = p.getPrice();
        d.inStock = p.getStock() != null && p.getStock() > 0;
        return d;
    }
}

