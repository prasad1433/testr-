package com.example.inventorymngt.Controllers;

import com.example.inventorymngt.entity.ProductEntitiy;
import com.example.inventorymngt.service.ProductService;
import com.example.inventorymngt.web.dto.StoreProductDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/store/products")
public class StoreController {

    private final ProductService productService;

    public StoreController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public List<StoreProductDto> list() {
        return productService.getProducts().stream()
                .map(StoreProductDto::from)
                .toList();
    }

    @GetMapping("/{id}")
    public StoreProductDto get(@PathVariable Long id) {
        ProductEntitiy product = productService.getProduct(id);
        return StoreProductDto.from(product);
    }
}

