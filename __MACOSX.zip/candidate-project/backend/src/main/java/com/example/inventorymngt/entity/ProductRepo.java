package com.example.inventorymngt.entity;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ProductRepo extends JpaRepository<ProductEntitiy, Long> {
    List<ProductEntitiy> findAllByDeletedFalseOrderByIdAsc();
    Optional<ProductEntitiy> findByIdAndDeletedFalse(Long id);
}
