package com.example.inventorymngt.web.dto;

import com.example.inventorymngt.entity.OrderEntity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class OrderDto {
    public Long id;
    public String status;
    public Long userId;
    public Long productId;
    public String productName;
    public Integer quantity;
    public BigDecimal unitPrice;
    public BigDecimal totalAmount;
    public LocalDateTime createdAt;

    public static OrderDto from(OrderEntity o) {
        OrderDto d = new OrderDto();
        d.id = o.getId();
        d.status = o.getStatus().name();
        d.userId = o.getUserId();
        d.productId = o.getProductId();
        d.productName = o.getProductName();
        d.quantity = o.getQuantity();
        d.unitPrice = o.getUnitPrice();
        d.totalAmount = o.getTotalAmount();
        d.createdAt = o.getCreatedAt();
        return d;
    }
}

