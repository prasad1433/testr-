package com.example.inventorymngt.web.dto;

import java.math.BigDecimal;

public class ProductRequest {
    public String name;
    public String description;
    public String category;
    public BigDecimal price;
}

