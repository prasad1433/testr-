package com.example.inventorymngt.service;

import com.example.inventorymngt.entity.OrderEntity;
import com.example.inventorymngt.entity.OrderRepo;
import com.example.inventorymngt.entity.OrderStatus;
import com.example.inventorymngt.entity.ProductEntitiy;
import com.example.inventorymngt.entity.ProductRepo;
import com.example.inventorymngt.web.BadRequestException;
import com.example.inventorymngt.web.NotFoundException;
import com.example.inventorymngt.web.dto.PlaceOrderRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderService {

    private static final int MAX_QUANTITY = 999;
    private static final int MAX_STOCK = 999_999;

    private final OrderRepo orderRepo;
    private final ProductRepo productRepo;

    public OrderService(OrderRepo orderRepo, ProductRepo productRepo) {
        this.orderRepo = orderRepo;
        this.productRepo = productRepo;
    }

    public List<OrderEntity> listOrders(Long userId) {
        if (userId != null) {
            return orderRepo.findAllByUserIdOrderByCreatedAtDesc(userId);
        }
        return orderRepo.findAllByOrderByCreatedAtDesc();
    }

    public OrderEntity getOrder(Long id) {
        return orderRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("Order " + id + " not found"));
    }

    @Transactional
    public OrderEntity placeOrder(PlaceOrderRequest req) {
        if (req == null) throw new BadRequestException("Request body is required");
        if (req.userId == null) throw new BadRequestException("userId is required");
        if (req.productId == null) throw new BadRequestException("productId is required");
        if (req.quantity == null || req.quantity < 1) {
            throw new BadRequestException("Quantity must be at least 1");
        }
        if (req.quantity > MAX_QUANTITY) {
            throw new BadRequestException("Quantity must be at most " + MAX_QUANTITY);
        }

        ProductEntitiy product = productRepo.findByIdAndDeletedFalse(req.productId)
                .orElseThrow(() -> new NotFoundException("Product " + req.productId + " not found"));

        int currentStock = product.getStock() == null ? 0 : product.getStock();
        if (currentStock < req.quantity) {
            throw new BadRequestException("Insufficient stock for product " + product.getName()
                    + " (requested " + req.quantity + ", available " + currentStock + ")");
        }

        // Deduct stock atomically with order creation.
        product.setStock(currentStock - req.quantity);
        productRepo.save(product);

        OrderEntity order = new OrderEntity();
        order.setStatus(OrderStatus.CREATED);
        order.setUserId(req.userId);
        order.setProductId(product.getId());
        order.setProductName(product.getName());
        order.setQuantity(req.quantity);
        order.setUnitPrice(product.getPrice());
        order.setTotalAmount(product.getPrice().multiply(BigDecimal.valueOf(req.quantity)));
        return orderRepo.save(order);
    }

    @Transactional
    public OrderEntity cancelOrder(Long id) {
        OrderEntity order = getOrder(id);
        if (order.getStatus() != OrderStatus.CREATED) {
            throw new BadRequestException("Only orders with status CREATED can be cancelled");
        }
        order.setStatus(OrderStatus.CANCELLED);
        // Restore stock if the product still exists (even soft-deleted, we restore).
        productRepo.findById(order.getProductId()).ifPresent(p -> {
            int current = p.getStock() == null ? 0 : p.getStock();
            int restored = current + order.getQuantity();
            if (restored > MAX_STOCK) {
                throw new BadRequestException("Cannot restore stock beyond " + MAX_STOCK);
            }
            p.setStock(restored);
            productRepo.save(p);
        });
        return orderRepo.save(order);
    }
}

