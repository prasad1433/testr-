package com.example.inventorymngt.Controllers;

import com.example.inventorymngt.service.ProductService;
import com.example.inventorymngt.web.dto.ProductDto;
import com.example.inventorymngt.web.dto.ProductRequest;
import com.example.inventorymngt.web.BadRequestException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public List<ProductDto> list() {
        return productService.getProducts().stream().map(ProductDto::from).toList();
    }

    @GetMapping("/{id}")
    public ProductDto get(@PathVariable Long id) {
        return ProductDto.from(productService.getProduct(id));
    }

    @PostMapping
    public ProductDto add(@RequestBody ProductRequest payload) {
        return ProductDto.from(productService.addProduct(payload));
    }

    @PutMapping("/{id}")
    public ProductDto update(@PathVariable Long id, @RequestBody ProductRequest payload) {
        return ProductDto.from(productService.updateProduct(id, payload));
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        productService.deleteProduct(id);
    }

    @PatchMapping("/{id}/stock")
    public ProductDto adjustStock(@PathVariable Long id, @RequestParam Integer amount) {
        if (amount == null) {
            throw new BadRequestException("amount query parameter is required");
        }
        return ProductDto.from(productService.adjustStock(id, amount));
    }
}
