package com.example.inventorymngt.web.dto;

public class PlaceOrderRequest {
    public Long userId;
    public Long productId;
    public Integer quantity;
}

