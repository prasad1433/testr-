package com.example.inventorymngt.service;

import com.example.inventorymngt.entity.ProductEntitiy;
import com.example.inventorymngt.entity.ProductRepo;
import com.example.inventorymngt.web.BadRequestException;
import com.example.inventorymngt.web.dto.ProductRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepo productRepo;

    private ProductService productService;

    @BeforeEach
    void setUp() {
        productService = new ProductService(productRepo);
    }

    @Test
    void addProductSetsStockToZero() {
        ProductRequest req = new ProductRequest();
        req.name = " Laptop ";
        req.description = "16GB RAM";
        req.category = "Electronics";
        req.price = new BigDecimal("1299.99");

        when(productRepo.save(any(ProductEntitiy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ProductEntitiy saved = productService.addProduct(req);

        assertEquals("Laptop", saved.getName());
        assertEquals(0, saved.getStock());
        assertEquals(new BigDecimal("1299.99"), saved.getPrice());
    }

    @Test
    void addProductRejectsPriceWithMoreThanTwoDecimals() {
        ProductRequest req = new ProductRequest();
        req.name = "Mouse";
        req.category = "Electronics";
        req.price = new BigDecimal("19.999");

        assertThrows(BadRequestException.class, () -> productService.addProduct(req));
    }

    @Test
    void adjustStockRejectsWhenResultWouldGoNegative() {
        ProductEntitiy existing = new ProductEntitiy();
        existing.setId(1L);
        existing.setStock(1);

        when(productRepo.findByIdAndDeletedFalse(1L)).thenReturn(Optional.of(existing));

        assertThrows(BadRequestException.class, () -> productService.adjustStock(1L, -2));
    }

    @Test
    void adjustStockPersistsNewValue() {
        ProductEntitiy existing = new ProductEntitiy();
        existing.setId(2L);
        existing.setStock(3);

        when(productRepo.findByIdAndDeletedFalse(2L)).thenReturn(Optional.of(existing));
        when(productRepo.save(any(ProductEntitiy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        productService.adjustStock(2L, 7);

        ArgumentCaptor<ProductEntitiy> captor = ArgumentCaptor.forClass(ProductEntitiy.class);
        verify(productRepo).save(captor.capture());
        assertEquals(10, captor.getValue().getStock());
    }
}

