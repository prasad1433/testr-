package com.example.inventorymngt.service;

import com.example.inventorymngt.entity.OrderEntity;
import com.example.inventorymngt.entity.OrderRepo;
import com.example.inventorymngt.entity.OrderStatus;
import com.example.inventorymngt.entity.ProductEntitiy;
import com.example.inventorymngt.entity.ProductRepo;
import com.example.inventorymngt.web.BadRequestException;
import com.example.inventorymngt.web.dto.PlaceOrderRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepo orderRepo;

    @Mock
    private ProductRepo productRepo;

    private OrderService orderService;

    @BeforeEach
    void setUp() {
        orderService = new OrderService(orderRepo, productRepo);
    }

    @Test
    void placeOrderRejectsInsufficientStock() {
        ProductEntitiy product = new ProductEntitiy();
        product.setId(5L);
        product.setName("Keyboard");
        product.setPrice(new BigDecimal("49.99"));
        product.setStock(1);

        when(productRepo.findByIdAndDeletedFalse(5L)).thenReturn(Optional.of(product));

        PlaceOrderRequest req = new PlaceOrderRequest();
        req.userId = 10L;
        req.productId = 5L;
        req.quantity = 2;

        assertThrows(BadRequestException.class, () -> orderService.placeOrder(req));
    }

    @Test
    void placeOrderDeductsStockAndSnapshotsPrice() {
        ProductEntitiy product = new ProductEntitiy();
        product.setId(7L);
        product.setName("Headphones");
        product.setPrice(new BigDecimal("10.00"));
        product.setStock(5);

        when(productRepo.findByIdAndDeletedFalse(7L)).thenReturn(Optional.of(product));
        when(productRepo.save(any(ProductEntitiy.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(orderRepo.save(any(OrderEntity.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PlaceOrderRequest req = new PlaceOrderRequest();
        req.userId = 100L;
        req.productId = 7L;
        req.quantity = 2;

        OrderEntity created = orderService.placeOrder(req);

        assertEquals(OrderStatus.CREATED, created.getStatus());
        assertEquals("Headphones", created.getProductName());
        assertEquals(new BigDecimal("10.00"), created.getUnitPrice());
        assertEquals(new BigDecimal("20.00"), created.getTotalAmount());

        ArgumentCaptor<ProductEntitiy> stockCaptor = ArgumentCaptor.forClass(ProductEntitiy.class);
        verify(productRepo).save(stockCaptor.capture());
        assertEquals(3, stockCaptor.getValue().getStock());
    }

    @Test
    void cancelOrderRejectsWhenOrderIsNotCreated() {
        OrderEntity order = new OrderEntity();
        order.setId(11L);
        order.setStatus(OrderStatus.CANCELLED);

        when(orderRepo.findById(11L)).thenReturn(Optional.of(order));

        assertThrows(BadRequestException.class, () -> orderService.cancelOrder(11L));
    }

    @Test
    void cancelOrderRejectsWhenRestoredStockWouldExceedLimit() {
        OrderEntity order = new OrderEntity();
        order.setId(12L);
        order.setStatus(OrderStatus.CREATED);
        order.setProductId(99L);
        order.setQuantity(10);

        ProductEntitiy product = new ProductEntitiy();
        product.setId(99L);
        product.setStock(999_995);

        when(orderRepo.findById(12L)).thenReturn(Optional.of(order));
        when(productRepo.findById(99L)).thenReturn(Optional.of(product));

        assertThrows(BadRequestException.class, () -> orderService.cancelOrder(12L));
    }
}

