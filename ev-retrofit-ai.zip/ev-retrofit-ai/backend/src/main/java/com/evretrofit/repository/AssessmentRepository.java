package com.evretrofit.repository;

import com.evretrofit.model.Assessment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface AssessmentRepository extends JpaRepository<Assessment, Long> {
    List<Assessment> findByVehicleIdOrderByCreatedAtDesc(Long vehicleId);
    Optional<Assessment> findTopByVehicleIdOrderByCreatedAtDesc(Long vehicleId);
}
