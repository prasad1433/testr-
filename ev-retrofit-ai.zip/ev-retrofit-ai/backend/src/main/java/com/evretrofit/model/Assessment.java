package com.evretrofit.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "assessments")
@Data
@NoArgsConstructor
public class Assessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    // Feasibility
    private Double feasibilityScore; // 0.0 - 1.0
    private String feasibilityGrade; // EXCELLENT, GOOD, FAIR, NOT_RECOMMENDED

    // Recommended configuration
    private String recommendedMotorType; // BLDC, PMSM, AC_INDUCTION
    private Double recommendedMotorPowerKW;
    private Double recommendedBatteryCapacityKWh;
    private String recommendedBatteryChemistry; // LFP, NMC, NCA
    private Double estimatedRangeKm;
    private Double estimatedCostINR;

    // Weight & space
    private Double availableBatterySpaceL;
    private Double estimatedWeightAddedKg;
    private String weightDistributionNote;

    // Compliance
    private Boolean aisCompliant;
    private String complianceNotes;

    // AI reasoning
    @Column(columnDefinition = "TEXT")
    private String aiInsights;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
