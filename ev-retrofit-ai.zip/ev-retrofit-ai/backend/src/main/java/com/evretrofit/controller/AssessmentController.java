package com.evretrofit.controller;

import com.evretrofit.model.Assessment;
import com.evretrofit.model.Vehicle;
import com.evretrofit.repository.VehicleRepository;
import com.evretrofit.service.FeasibilityService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/assessments")
@RequiredArgsConstructor
public class AssessmentController {

    private final FeasibilityService feasibilityService;
    private final VehicleRepository vehicleRepository;

    @PostMapping("/vehicle/{vehicleId}")
    public ResponseEntity<Assessment> runAssessment(@PathVariable Long vehicleId) {
        return vehicleRepository.findById(vehicleId)
                .map(v -> ResponseEntity.ok(feasibilityService.assess(v)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<List<Assessment>> getForVehicle(@PathVariable Long vehicleId) {
        List<Assessment> results = feasibilityService.getForVehicle(vehicleId);
        return ResponseEntity.ok(results);
    }
}
