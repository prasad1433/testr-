package com.evretrofit.service;

import com.evretrofit.model.Assessment;
import com.evretrofit.model.Vehicle;
import com.evretrofit.repository.AssessmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FeasibilityService {

    private final AssessmentRepository assessmentRepository;

    /**
     * Runs a rule-based + weighted AI scoring model to assess EV retrofit feasibility.
     * Scoring factors: vehicle age, odometer, body type, condition scores, weight class.
     */
    public Assessment assess(Vehicle vehicle) {
        Assessment assessment = new Assessment();
        assessment.setVehicle(vehicle);

        double score = computeFeasibilityScore(vehicle);
        assessment.setFeasibilityScore(score);
        assessment.setFeasibilityGrade(gradeFromScore(score));

        applyMotorRecommendation(vehicle, assessment);
        applyBatteryRecommendation(vehicle, assessment);
        applyComplianceCheck(assessment);
        assessment.setAiInsights(generateInsights(vehicle, assessment));

        return assessmentRepository.save(assessment);
    }

    public List<Assessment> getForVehicle(Long vehicleId) {
        return assessmentRepository.findByVehicleIdOrderByCreatedAtDesc(vehicleId);
    }

    // -------------------------------------------------------------------------
    // Private scoring logic
    // -------------------------------------------------------------------------

    private double computeFeasibilityScore(Vehicle v) {
        double score = 1.0;

        // Age penalty
        int age = 2026 - (v.getYear() != null ? v.getYear() : 2010);
        if (age > 15) score -= 0.25;
        else if (age > 10) score -= 0.10;

        // Odometer penalty
        double km = v.getOdometerKm() != null ? v.getOdometerKm() : 0;
        if (km > 200_000) score -= 0.20;
        else if (km > 100_000) score -= 0.10;

        // Chassis condition (most important structural factor)
        int chassis = v.getChassisConditionScore() != null ? v.getChassisConditionScore() : 70;
        score += (chassis - 70) * 0.003;

        // Engine condition is less critical for EV conversion
        int engine = v.getEngineConditionScore() != null ? v.getEngineConditionScore() : 70;
        score += (engine - 70) * 0.001;

        // Electrical condition bonus
        int electrical = v.getElectricalConditionScore() != null ? v.getElectricalConditionScore() : 70;
        score += (electrical - 70) * 0.002;

        // Body type feasibility
        if ("TWO_WHEELER".equals(v.getBodyType())) score += 0.10;
        else if ("THREE_WHEELER".equals(v.getBodyType())) score += 0.05;
        else if ("LCV".equals(v.getBodyType())) score -= 0.05;

        return Math.max(0.0, Math.min(1.0, score));
    }

    private String gradeFromScore(double score) {
        if (score >= 0.80) return "EXCELLENT";
        if (score >= 0.60) return "GOOD";
        if (score >= 0.40) return "FAIR";
        return "NOT_RECOMMENDED";
    }

    private void applyMotorRecommendation(Vehicle v, Assessment a) {
        double weightKg = v.getVehicleWeightKg() != null ? v.getVehicleWeightKg() : 1000;
        if (weightKg < 400) {
            a.setRecommendedMotorType("BLDC");
            a.setRecommendedMotorPowerKW(5.0);
        } else if (weightKg < 1200) {
            a.setRecommendedMotorType("PMSM");
            a.setRecommendedMotorPowerKW(15.0);
        } else {
            a.setRecommendedMotorType("AC_INDUCTION");
            a.setRecommendedMotorPowerKW(30.0);
        }
    }

    private void applyBatteryRecommendation(Vehicle v, Assessment a) {
        double powerKW = a.getRecommendedMotorPowerKW() != null ? a.getRecommendedMotorPowerKW() : 15.0;
        double capacityKWh = powerKW * 0.5; // rough sizing: 0.5 kWh per kW for ~100 km range
        a.setRecommendedBatteryCapacityKWh(capacityKWh);
        a.setRecommendedBatteryChemistry("LFP"); // LFP preferred for India: cost + thermal stability
        a.setEstimatedRangeKm(capacityKWh * 8); // ~8 km/kWh average
        a.setEstimatedCostINR(capacityKWh * 25000); // ~₹25,000 per kWh
        a.setAvailableBatterySpaceL(capacityKWh * 4); // ~4L per kWh
        a.setEstimatedWeightAddedKg(capacityKWh * 7); // ~7 kg per kWh for LFP
        a.setWeightDistributionNote("Place battery packs low in chassis to maintain centre of gravity.");
    }

    private void applyComplianceCheck(Assessment a) {
        boolean compliant = !"NOT_RECOMMENDED".equals(a.getFeasibilityGrade());
        a.setAisCompliant(compliant);
        a.setComplianceNotes(compliant
                ? "Configuration meets AIS-048 and AIS-156 base requirements. Final certification required post-conversion."
                : "Vehicle condition does not meet minimum AIS safety thresholds for EV conversion.");
    }

    private String generateInsights(Vehicle v, Assessment a) {
        return String.format(
                "Vehicle: %d %s %s (%s). Feasibility: %s (%.0f%%). " +
                "Recommended: %s motor at %.1f kW with %.1f kWh LFP battery pack. " +
                "Estimated range: %.0f km. Estimated cost: ₹%.0f. %s",
                v.getYear(), v.getMake(), v.getModel(), v.getBodyType(),
                a.getFeasibilityGrade(), a.getFeasibilityScore() * 100,
                a.getRecommendedMotorType(), a.getRecommendedMotorPowerKW(),
                a.getRecommendedBatteryCapacityKWh(),
                a.getEstimatedRangeKm(), a.getEstimatedCostINR(),
                a.getComplianceNotes()
        );
    }
}
