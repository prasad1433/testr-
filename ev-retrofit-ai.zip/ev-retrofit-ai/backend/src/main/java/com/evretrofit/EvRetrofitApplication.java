package com.evretrofit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvRetrofitApplication {
    public static void main(String[] args) {
        SpringApplication.run(EvRetrofitApplication.class, args);
    }
}
