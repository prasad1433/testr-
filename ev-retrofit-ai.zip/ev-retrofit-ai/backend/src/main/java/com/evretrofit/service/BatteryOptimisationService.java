package com.evretrofit.service;

import com.evretrofit.model.BatteryConfig;
import com.evretrofit.model.Vehicle;
import com.evretrofit.repository.BatteryConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BatteryOptimisationService {

    private final BatteryConfigRepository batteryConfigRepository;

    /**
     * Generates an optimised battery configuration for a given vehicle
     * based on required capacity, body type, and space constraints.
     */
    public BatteryConfig optimise(Vehicle vehicle, double requiredCapacityKWh) {
        BatteryConfig config = new BatteryConfig();
        config.setVehicle(vehicle);
        config.setChemistry("LFP");
        config.setCapacityKWh(requiredCapacityKWh);

        // Voltage & cell configuration
        double nominalVoltage = selectNominalVoltage(vehicle);
        config.setNominalVoltageV(nominalVoltage);

        int series = (int) Math.round(nominalVoltage / 3.2); // LFP cell ~3.2V nominal
        int parallel = (int) Math.ceil((requiredCapacityKWh * 1000) / (series * 3.2 * 50)); // 50Ah cells
        config.setCellCount(series * parallel);
        config.setSeriesParallelConfig(series + "S" + parallel + "P");

        // Placement zone based on body type
        String bodyType = vehicle.getBodyType() != null ? vehicle.getBodyType() : "SEDAN";
        config.setPlacementZone(selectPlacementZone(bodyType));

        // Physical dimensions (approximate for selected capacity)
        double volumeL = requiredCapacityKWh * 4.5;
        config.setPlacementLengthMm(Math.round(volumeL * 0.6 * 10) * 10.0); // rough cuboid
        config.setPlacementWidthMm(400.0);
        config.setPlacementHeightMm(Math.round((volumeL / (config.getPlacementLengthMm() / 1000 * 0.4)) * 1000));
        config.setTotalWeightKg(requiredCapacityKWh * 7.0); // LFP ~7 kg/kWh

        // Thermal management
        config.setCoolingType(requiredCapacityKWh > 20 ? "LIQUID" : "AIR");
        config.setEstimatedThermalLoadW(requiredCapacityKWh * 50);

        // Safety
        config.setBmsRequired(true);
        config.setSafetyStandard("AIS-156");
        config.setFireSafetyCompliant(true);

        config.setOptimisationNotes(
                String.format("Optimised %s placement with %s cooling. " +
                        "Configuration: %s (%d cells). " +
                        "BMS mandatory for cell balancing and thermal protection.",
                        config.getPlacementZone(), config.getCoolingType(),
                        config.getSeriesParallelConfig(), config.getCellCount())
        );

        return batteryConfigRepository.save(config);
    }

    public List<BatteryConfig> getForVehicle(Long vehicleId) {
        return batteryConfigRepository.findByVehicleIdOrderByCreatedAtDesc(vehicleId);
    }

    private double selectNominalVoltage(Vehicle v) {
        String body = v.getBodyType() != null ? v.getBodyType() : "SEDAN";
        return switch (body) {
            case "TWO_WHEELER" -> 48.0;
            case "THREE_WHEELER" -> 48.0;
            case "LCV" -> 96.0;
            default -> 72.0; // cars
        };
    }

    private String selectPlacementZone(String bodyType) {
        return switch (bodyType) {
            case "TWO_WHEELER" -> "UNDERFLOOR";
            case "THREE_WHEELER" -> "UNDERFLOOR";
            case "LCV" -> "TRUNK";
            case "SUV" -> "UNDERFLOOR";
            default -> "COMBINED"; // front boot + under floor for sedans/hatchbacks
        };
    }
}
