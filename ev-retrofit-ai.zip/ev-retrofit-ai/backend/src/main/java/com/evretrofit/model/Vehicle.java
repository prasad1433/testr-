package com.evretrofit.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "vehicles")
@Data
@NoArgsConstructor
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String make;

    @Column(nullable = false)
    private String model;

    @Column(nullable = false)
    private Integer year;

    private String fuelType;

    private Double engineDisplacementCC;

    private Double vehicleWeightKg;

    private String transmissionType; // MANUAL, AUTOMATIC

    private Double odometerKm;

    private String bodyType; // SEDAN, SUV, HATCHBACK, TWO_WHEELER, THREE_WHEELER, LCV

    private String chassisNumber;

    private String registrationNumber;

    // Condition fields
    private Integer engineConditionScore; // 0-100
    private Integer chassisConditionScore; // 0-100
    private Integer electricalConditionScore; // 0-100
    private Integer brakeConditionScore; // 0-100

    private String imageUrl;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User owner;
}
