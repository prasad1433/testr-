package com.evretrofit.controller;

import com.evretrofit.model.BatteryConfig;
import com.evretrofit.repository.VehicleRepository;
import com.evretrofit.service.BatteryOptimisationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/battery-configs")
@RequiredArgsConstructor
public class BatteryConfigController {

    private final BatteryOptimisationService batteryOptimisationService;
    private final VehicleRepository vehicleRepository;

    @PostMapping("/vehicle/{vehicleId}/optimise")
    public ResponseEntity<BatteryConfig> optimise(
            @PathVariable Long vehicleId,
            @RequestBody Map<String, Double> body) {

        double requiredCapacityKWh = body.getOrDefault("requiredCapacityKWh", 10.0);

        return vehicleRepository.findById(vehicleId)
                .map(v -> ResponseEntity.ok(batteryOptimisationService.optimise(v, requiredCapacityKWh)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<List<BatteryConfig>> getForVehicle(@PathVariable Long vehicleId) {
        return ResponseEntity.ok(batteryOptimisationService.getForVehicle(vehicleId));
    }
}
