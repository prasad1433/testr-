package com.evretrofit.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "battery_configs")
@Data
@NoArgsConstructor
public class BatteryConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    private String chemistry; // LFP, NMC, NCA
    private Double capacityKWh;
    private Double nominalVoltageV;
    private Integer cellCount;
    private String seriesParallelConfig; // e.g. "4S2P"

    // Placement
    private String placementZone; // UNDERFLOOR, TRUNK, FRONT_BOOT, COMBINED
    private Double placementLengthMm;
    private Double placementWidthMm;
    private Double placementHeightMm;
    private Double totalWeightKg;

    // Thermal
    private String coolingType; // AIR, LIQUID, PHASE_CHANGE
    private Double estimatedThermalLoadW;

    // Safety
    private Boolean bmsRequired;
    private String safetyStandard; // AIS-048, AIS-156
    private Boolean fireSafetyCompliant;

    @Column(columnDefinition = "TEXT")
    private String optimisationNotes;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
