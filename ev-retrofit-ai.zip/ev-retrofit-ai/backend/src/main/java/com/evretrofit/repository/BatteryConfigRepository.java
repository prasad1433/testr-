package com.evretrofit.repository;

import com.evretrofit.model.BatteryConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BatteryConfigRepository extends JpaRepository<BatteryConfig, Long> {
    List<BatteryConfig> findByVehicleIdOrderByCreatedAtDesc(Long vehicleId);
}
