import axios from 'axios';
import type { Vehicle, Assessment, BatteryConfig, LoginRequest, SignupRequest, AuthResponse } from './types';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auth
export const login = (data: LoginRequest) =>
  api.post<AuthResponse>('/auth/login', data).then((r) => r.data);

export const signup = (data: SignupRequest) =>
  api.post<AuthResponse>('/auth/signup', data).then((r) => r.data);

// Vehicles
export const getVehicles = () =>
  api.get<Vehicle[]>('/vehicles').then((r) => r.data);

export const getVehicle = (id: number) =>
  api.get<Vehicle>(`/vehicles/${id}`).then((r) => r.data);

export const createVehicle = (data: Partial<Vehicle>) =>
  api.post<Vehicle>('/vehicles', data).then((r) => r.data);

export const updateVehicle = (id: number, data: Partial<Vehicle>) =>
  api.put<Vehicle>(`/vehicles/${id}`, data).then((r) => r.data);

export const deleteVehicle = (id: number) =>
  api.delete(`/vehicles/${id}`);

// Assessments
export const runAssessment = (vehicleId: number) =>
  api.post<Assessment>(`/assessments/vehicle/${vehicleId}`).then((r) => r.data);

export const getAssessments = (vehicleId: number) =>
  api.get<Assessment[]>(`/assessments/vehicle/${vehicleId}`).then((r) => r.data);

// Battery Configs
export const optimiseBattery = (vehicleId: number, requiredCapacityKWh: number) =>
  api.post<BatteryConfig>(`/battery-configs/vehicle/${vehicleId}/optimise`, { requiredCapacityKWh })
    .then((r) => r.data);

export const getBatteryConfigs = (vehicleId: number) =>
  api.get<BatteryConfig[]>(`/battery-configs/vehicle/${vehicleId}`).then((r) => r.data);
