import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getVehicles, deleteVehicle } from '../api';
import type { Vehicle } from '../types';
import { Trash2, Eye } from 'lucide-react';

const VehiclesPage: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => getVehicles().then(setVehicles).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this vehicle?')) return;
    await deleteVehicle(id);
    setVehicles((prev) => prev.filter((v) => v.id !== id));
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Vehicles</h2>
        <Link
          to="/vehicles/new"
          className="bg-green-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
        >
          + Add Vehicle
        </Link>
      </div>

      {loading ? (
        <p className="text-gray-400 text-sm">Loading…</p>
      ) : vehicles.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-10 text-center text-gray-400">
          <p className="mb-3">No vehicles registered.</p>
          <Link to="/vehicles/new" className="text-green-600 hover:underline text-sm">Add your first vehicle →</Link>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-500 uppercase text-xs">
              <tr>
                <th className="px-4 py-3 text-left">Vehicle</th>
                <th className="px-4 py-3 text-left">Body Type</th>
                <th className="px-4 py-3 text-left">Odometer</th>
                <th className="px-4 py-3 text-left">Fuel</th>
                <th className="px-4 py-3 text-left">Chassis Score</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {vehicles.map((v) => (
                <tr key={v.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-800">{v.year} {v.make} {v.model}</td>
                  <td className="px-4 py-3 text-gray-500">{v.bodyType}</td>
                  <td className="px-4 py-3 text-gray-500">{v.odometerKm?.toLocaleString()} km</td>
                  <td className="px-4 py-3 text-gray-500">{v.fuelType}</td>
                  <td className="px-4 py-3">
                    <span className={`font-medium ${v.chassisConditionScore >= 70 ? 'text-green-600' : 'text-amber-500'}`}>
                      {v.chassisConditionScore}/100
                    </span>
                  </td>
                  <td className="px-4 py-3 flex gap-2 justify-end">
                    <Link to={`/vehicles/${v.id}`} className="text-blue-500 hover:text-blue-700">
                      <Eye size={16} />
                    </Link>
                    <button onClick={() => handleDelete(v.id)} className="text-red-400 hover:text-red-600">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default VehiclesPage;
