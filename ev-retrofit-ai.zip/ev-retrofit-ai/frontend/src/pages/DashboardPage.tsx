import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getVehicles } from '../api';
import type { Vehicle } from '../types';
import { Car, Zap, CheckCircle, AlertTriangle } from 'lucide-react';

const DashboardPage: React.FC = () => {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getVehicles()
      .then(setVehicles)
      .finally(() => setLoading(false));
  }, []);

  const stats = [
    { label: 'Total Vehicles', value: vehicles.length, icon: <Car size={20} className="text-blue-500" /> },
    { label: 'Assessments Run', value: '-', icon: <Zap size={20} className="text-green-500" /> },
    { label: 'AIS Compliant', value: '-', icon: <CheckCircle size={20} className="text-emerald-500" /> },
    { label: 'Needs Review', value: '-', icon: <AlertTriangle size={20} className="text-amber-500" /> },
  ];

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
        <p className="text-gray-500 text-sm mt-1">EV Retrofit Feasibility Platform — ET AutoTech Hackathon 2026</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {stats.map((s) => (
          <div key={s.label} className="bg-white rounded-xl shadow-sm p-4 flex items-center gap-3">
            {s.icon}
            <div>
              <div className="text-2xl font-bold text-gray-800">{loading ? '…' : s.value}</div>
              <div className="text-xs text-gray-500">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent vehicles */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-700">Recent Vehicles</h3>
          <Link to="/vehicles/new" className="text-sm bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 transition-colors">
            + Add Vehicle
          </Link>
        </div>
        {loading ? (
          <p className="text-sm text-gray-400">Loading…</p>
        ) : vehicles.length === 0 ? (
          <p className="text-sm text-gray-400">No vehicles yet. Add your first vehicle to run an assessment.</p>
        ) : (
          <div className="divide-y">
            {vehicles.slice(0, 5).map((v) => (
              <Link key={v.id} to={`/vehicles/${v.id}`} className="flex items-center justify-between py-3 hover:bg-gray-50 px-2 rounded-lg">
                <div>
                  <div className="font-medium text-sm text-gray-800">{v.year} {v.make} {v.model}</div>
                  <div className="text-xs text-gray-400">{v.bodyType} · {v.odometerKm?.toLocaleString()} km</div>
                </div>
                <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{v.fuelType}</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
