import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createVehicle } from '../api';

const BODY_TYPES = ['SEDAN', 'SUV', 'HATCHBACK', 'TWO_WHEELER', 'THREE_WHEELER', 'LCV'];
const FUEL_TYPES = ['PETROL', 'DIESEL', 'CNG', 'LPG'];
const TRANSMISSIONS = ['MANUAL', 'AUTOMATIC'];

const AddVehiclePage: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    make: '', model: '', year: 2018, fuelType: 'PETROL',
    engineDisplacementCC: 1200, vehicleWeightKg: 1000,
    transmissionType: 'MANUAL', odometerKm: 50000,
    bodyType: 'SEDAN', chassisNumber: '', registrationNumber: '',
    engineConditionScore: 75, chassisConditionScore: 80,
    electricalConditionScore: 70, brakeConditionScore: 80,
  });

  const set = (field: string, value: string | number) => setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const vehicle = await createVehicle(form);
      navigate(`/vehicles/${vehicle.id}`);
    } catch {
      setError('Failed to save vehicle. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const field = (label: string, name: keyof typeof form, type = 'text', options?: string[]) => (
    <div>
      <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
      {options ? (
        <select
          className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          value={form[name]}
          onChange={(e) => set(name, e.target.value)}
        >
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input
          type={type}
          className="w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
          value={form[name]}
          onChange={(e) => set(name, type === 'number' ? Number(e.target.value) : e.target.value)}
        />
      )}
    </div>
  );

  return (
    <div className="p-6 max-w-2xl">
      <h2 className="text-2xl font-bold text-gray-800 mb-1">Add Vehicle</h2>
      <p className="text-gray-500 text-sm mb-6">Enter vehicle details to run an EV retrofit feasibility assessment.</p>

      {error && <div className="bg-red-50 text-red-600 text-sm rounded-lg p-3 mb-4">{error}</div>}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          {field('Make', 'make')}
          {field('Model', 'model')}
          {field('Year', 'year', 'number')}
          {field('Fuel Type', 'fuelType', 'text', FUEL_TYPES)}
          {field('Body Type', 'bodyType', 'text', BODY_TYPES)}
          {field('Transmission', 'transmissionType', 'text', TRANSMISSIONS)}
          {field('Engine Displacement (CC)', 'engineDisplacementCC', 'number')}
          {field('Vehicle Weight (kg)', 'vehicleWeightKg', 'number')}
          {field('Odometer (km)', 'odometerKm', 'number')}
          {field('Registration Number', 'registrationNumber')}
        </div>

        <h3 className="font-semibold text-gray-700 pt-2 border-t">Condition Scores (0–100)</h3>
        <div className="grid grid-cols-2 gap-4">
          {field('Engine Condition', 'engineConditionScore', 'number')}
          {field('Chassis Condition', 'chassisConditionScore', 'number')}
          {field('Electrical Condition', 'electricalConditionScore', 'number')}
          {field('Brake Condition', 'brakeConditionScore', 'number')}
        </div>

        <div className="flex gap-3 pt-2">
          <button
            type="submit"
            disabled={loading}
            className="bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
          >
            {loading ? 'Saving…' : 'Save Vehicle'}
          </button>
          <button
            type="button"
            onClick={() => navigate('/vehicles')}
            className="border px-5 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddVehiclePage;
