import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getVehicle, runAssessment, getAssessments, optimiseBattery, getBatteryConfigs } from '../api';
import type { Vehicle, Assessment, BatteryConfig } from '../types';
import { Zap, Battery, CheckCircle, XCircle } from 'lucide-react';

const gradeColor: Record<string, string> = {
  EXCELLENT: 'bg-emerald-100 text-emerald-700',
  GOOD: 'bg-green-100 text-green-700',
  FAIR: 'bg-amber-100 text-amber-700',
  NOT_RECOMMENDED: 'bg-red-100 text-red-700',
};

const VehicleDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const vehicleId = Number(id);

  const [vehicle, setVehicle] = useState<Vehicle | null>(null);
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [batteryConfigs, setBatteryConfigs] = useState<BatteryConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [assessing, setAssessing] = useState(false);
  const [optimising, setOptimising] = useState(false);

  useEffect(() => {
    Promise.all([
      getVehicle(vehicleId),
      getAssessments(vehicleId),
      getBatteryConfigs(vehicleId),
    ]).then(([v, a, b]) => {
      setVehicle(v);
      setAssessments(a);
      setBatteryConfigs(b);
    }).catch(() => navigate('/vehicles'))
      .finally(() => setLoading(false));
  }, [vehicleId, navigate]);

  const handleAssess = async () => {
    setAssessing(true);
    try {
      const result = await runAssessment(vehicleId);
      setAssessments((prev) => [result, ...prev]);
    } finally {
      setAssessing(false);
    }
  };

  const handleOptimise = async () => {
    if (!assessments[0]) return;
    setOptimising(true);
    try {
      const config = await optimiseBattery(vehicleId, assessments[0].recommendedBatteryCapacityKWh);
      setBatteryConfigs((prev) => [config, ...prev]);
    } finally {
      setOptimising(false);
    }
  };

  if (loading) return <div className="p-6 text-gray-400">Loading…</div>;
  if (!vehicle) return null;

  const latest = assessments[0];
  const latestBattery = batteryConfigs[0];

  return (
    <div className="p-6 max-w-4xl space-y-6">
      {/* Vehicle Header */}
      <div className="bg-white rounded-xl shadow-sm p-5">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{vehicle.year} {vehicle.make} {vehicle.model}</h2>
            <p className="text-gray-400 text-sm">{vehicle.bodyType} · {vehicle.fuelType} · {vehicle.odometerKm?.toLocaleString()} km</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleAssess}
              disabled={assessing}
              className="flex items-center gap-2 bg-green-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
            >
              <Zap size={14} /> {assessing ? 'Assessing…' : 'Run Assessment'}
            </button>
            {latest && (
              <button
                onClick={handleOptimise}
                disabled={optimising}
                className="flex items-center gap-2 bg-blue-600 text-white text-sm px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <Battery size={14} /> {optimising ? 'Optimising…' : 'Optimise Battery'}
              </button>
            )}
          </div>
        </div>

        {/* Condition scores */}
        <div className="grid grid-cols-4 gap-3 mt-5">
          {[
            { label: 'Engine', score: vehicle.engineConditionScore },
            { label: 'Chassis', score: vehicle.chassisConditionScore },
            { label: 'Electrical', score: vehicle.electricalConditionScore },
            { label: 'Brakes', score: vehicle.brakeConditionScore },
          ].map(({ label, score }) => (
            <div key={label} className="text-center bg-gray-50 rounded-lg p-3">
              <div className={`text-xl font-bold ${score >= 70 ? 'text-green-600' : 'text-amber-500'}`}>{score}</div>
              <div className="text-xs text-gray-500">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Latest Assessment */}
      {latest && (
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h3 className="font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <Zap size={16} className="text-green-500" /> Feasibility Assessment
          </h3>
          <div className="flex items-center gap-3 mb-4">
            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${gradeColor[latest.feasibilityGrade]}`}>
              {latest.feasibilityGrade}
            </span>
            <span className="text-2xl font-bold text-gray-800">{(latest.feasibilityScore * 100).toFixed(0)}%</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm mb-4">
            <div><div className="text-gray-400 text-xs">Motor</div><div className="font-medium">{latest.recommendedMotorType} — {latest.recommendedMotorPowerKW} kW</div></div>
            <div><div className="text-gray-400 text-xs">Battery</div><div className="font-medium">{latest.recommendedBatteryCapacityKWh} kWh ({latest.recommendedBatteryChemistry})</div></div>
            <div><div className="text-gray-400 text-xs">Est. Range</div><div className="font-medium">{latest.estimatedRangeKm} km</div></div>
            <div><div className="text-gray-400 text-xs">Est. Cost</div><div className="font-medium">₹{latest.estimatedCostINR?.toLocaleString()}</div></div>
            <div><div className="text-gray-400 text-xs">Weight Added</div><div className="font-medium">{latest.estimatedWeightAddedKg} kg</div></div>
            <div className="flex items-center gap-1">
              {latest.aisCompliant
                ? <><CheckCircle size={14} className="text-green-500" /><span className="text-green-600 font-medium">AIS Compliant</span></>
                : <><XCircle size={14} className="text-red-500" /><span className="text-red-600 font-medium">Not Compliant</span></>}
            </div>
          </div>
          <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-600 leading-relaxed">{latest.aiInsights}</div>
        </div>
      )}

      {/* Battery Config */}
      {latestBattery && (
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h3 className="font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <Battery size={16} className="text-blue-500" /> Battery Configuration
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div><div className="text-gray-400 text-xs">Chemistry</div><div className="font-medium">{latestBattery.chemistry}</div></div>
            <div><div className="text-gray-400 text-xs">Capacity</div><div className="font-medium">{latestBattery.capacityKWh} kWh @ {latestBattery.nominalVoltageV}V</div></div>
            <div><div className="text-gray-400 text-xs">Config</div><div className="font-medium">{latestBattery.seriesParallelConfig} ({latestBattery.cellCount} cells)</div></div>
            <div><div className="text-gray-400 text-xs">Placement</div><div className="font-medium">{latestBattery.placementZone}</div></div>
            <div><div className="text-gray-400 text-xs">Cooling</div><div className="font-medium">{latestBattery.coolingType}</div></div>
            <div><div className="text-gray-400 text-xs">Safety Standard</div><div className="font-medium">{latestBattery.safetyStandard}</div></div>
          </div>
          <div className="bg-blue-50 rounded-lg p-3 text-xs text-blue-700 mt-4 leading-relaxed">{latestBattery.optimisationNotes}</div>
        </div>
      )}
    </div>
  );
};

export default VehicleDetailPage;
