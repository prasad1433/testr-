// Vehicle types
export interface Vehicle {
  id: number;
  make: string;
  model: string;
  year: number;
  fuelType: string;
  engineDisplacementCC: number;
  vehicleWeightKg: number;
  transmissionType: 'MANUAL' | 'AUTOMATIC';
  odometerKm: number;
  bodyType: 'SEDAN' | 'SUV' | 'HATCHBACK' | 'TWO_WHEELER' | 'THREE_WHEELER' | 'LCV';
  chassisNumber?: string;
  registrationNumber?: string;
  engineConditionScore: number;
  chassisConditionScore: number;
  electricalConditionScore: number;
  brakeConditionScore: number;
  createdAt: string;
}

// Assessment
export interface Assessment {
  id: number;
  vehicle: Vehicle;
  feasibilityScore: number;
  feasibilityGrade: 'EXCELLENT' | 'GOOD' | 'FAIR' | 'NOT_RECOMMENDED';
  recommendedMotorType: string;
  recommendedMotorPowerKW: number;
  recommendedBatteryCapacityKWh: number;
  recommendedBatteryChemistry: string;
  estimatedRangeKm: number;
  estimatedCostINR: number;
  availableBatterySpaceL: number;
  estimatedWeightAddedKg: number;
  weightDistributionNote: string;
  aisCompliant: boolean;
  complianceNotes: string;
  aiInsights: string;
  createdAt: string;
}

// Battery Config
export interface BatteryConfig {
  id: number;
  vehicle: Vehicle;
  chemistry: string;
  capacityKWh: number;
  nominalVoltageV: number;
  cellCount: number;
  seriesParallelConfig: string;
  placementZone: string;
  placementLengthMm: number;
  placementWidthMm: number;
  placementHeightMm: number;
  totalWeightKg: number;
  coolingType: string;
  estimatedThermalLoadW: number;
  bmsRequired: boolean;
  safetyStandard: string;
  fireSafetyCompliant: boolean;
  optimisationNotes: string;
  createdAt: string;
}

// Auth
export interface AuthUser {
  id: number;
  email: string;
  fullName: string;
  role: 'USER' | 'ENGINEER' | 'ADMIN';
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  fullName: string;
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: AuthUser;
}
