# EV Retrofit AI — ET AutoTech Hackathon 2026

**Theme 2: AI for EV Retrofit & Conversion Ecosystem**

An end-to-end AI-driven platform that assesses vehicle feasibility for EV conversion, automates retrofit configuration recommendations, and optimises battery placement and wiring harness design.

---

## Features

- **Vehicle Condition Assessment** — Upload vehicle details/images to get an AI-driven health report
- **Feasibility Prediction** — ML-based scoring for EV retrofit viability
- **Retrofit Configuration Recommendations** — Suggest motor, battery, and drivetrain configurations
- **Battery Placement Optimisation** — Analyse chassis space constraints and recommend optimal layout
- **Wiring Harness Design** — Automated routing suggestions
- **Safety & Compliance Validation** — Check configurations against IS/AIS standards
- **Quality Assurance Dashboard** — Monitor conversion process deviations

---

## Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Backend   | Java 17, Spring Boot 3, Spring Data JPA |
| Database  | PostgreSQL                          |
| Frontend  | React 18, TypeScript, Tailwind CSS, Vite |
| Container | Docker, Docker Compose              |

---

## Getting Started

```bash
# Start all services
docker-compose up --build

# Backend runs on http://localhost:8080
# Frontend runs on http://localhost:5173
```

---

## Project Structure

```
ev-retrofit-ai/
├── backend/          # Spring Boot API
├── frontend/         # React + TypeScript UI
└── docker-compose.yml
```
